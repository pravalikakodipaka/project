package com.HCTConstructive.HCTdemo.model;

import jakarta.persistence.*;
import lombok.Data;

import java.sql.Timestamp;
@Entity
@Data
@Table(name="custaddress")
public class CustomerAddress {
    @Id
    private long addressid;
    @Column
    private String country;
    @Column
    private String  city;
    @Column
    private String addresslane;
    @Column
    private long pin;
    @Column
    private Timestamp lastupdate;

  @OneToOne(mappedBy = "customerAddress")
    private CustomerDetails customerDetails;
  public  String getAddresslane(String addresslane){
      return this.addresslane;
  }

}
