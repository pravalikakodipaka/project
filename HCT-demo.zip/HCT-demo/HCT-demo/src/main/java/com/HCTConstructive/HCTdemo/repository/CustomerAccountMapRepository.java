package com.HCTConstructive.HCTdemo.repository;

import com.HCTConstructive.HCTdemo.model.CustomerAccountMap;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface CustomerAccountMapRepository extends JpaRepository<CustomerAccountMap,Integer> {

    @Query(value = "select * from CusAccMap cam where cam.cust_id=:id " ,nativeQuery = true)
    CustomerAccountMap findByCustId(long id);
}
