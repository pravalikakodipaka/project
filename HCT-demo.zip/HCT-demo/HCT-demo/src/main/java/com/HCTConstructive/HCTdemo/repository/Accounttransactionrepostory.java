package com.HCTConstructive.HCTdemo.repository;

import com.HCTConstructive.HCTdemo.model.AccountBalance;
import com.HCTConstructive.HCTdemo.model.AccountTranscation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface Accounttransactionrepostory extends JpaRepository<AccountTranscation,Long> {




    @Query(value = "select * from AccountTransaction at where at.accountid=:accountid ",nativeQuery = true)
    List<AccountTranscation> findByAccId(long accountid);

    @Query(value = "select * from AccountTransaction bt where bt.transcationrefid=:transactionrefid ",nativeQuery = true)
    List<AccountTranscation> findByRefId(long transactionrefid);
    @Query(value = "SELECT * FROM AccountTransaction bt WHERE bt.accountid = :accountid AND bt.transcationrefid = :transactionrefid", nativeQuery = true)
    List<AccountTranscation> findByAccIdAndRefId(long accountid, long transactionrefid);
}
