package com.HCTConstructive.HCTdemo.repository;

import com.HCTConstructive.HCTdemo.model.CustomerAddress;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CustomerAddressRepository extends JpaRepository<CustomerAddress,Integer> {

}
