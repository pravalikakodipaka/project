package com.HCTConstructive.HCTdemo.model.Response;

import lombok.Data;

@Data
public class CustomerResponse {
    private String name;
    private long customerid;
    private long accountid;
    private double accountbalance;
    public CustomerResponse(String name,long customerid,long accountid,double accountbalance){

    }

    public CustomerResponse(String custname, long customerid) {
    }
}
