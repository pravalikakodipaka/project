package com.HCTConstructive.HCTdemo.controller;

import com.HCTConstructive.HCTdemo.CustomerService;
import com.HCTConstructive.HCTdemo.model.*;
import com.HCTConstructive.HCTdemo.model.Response.CustomerResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/hctbank")
public class CustomerController {

    // Assuming you have a service to handle account balance operations
    @Autowired
     CustomerService customerService;

    @GetMapping("/customers")
    public List<CustomerDetails> getCustomers(){
       return customerService.getCustomers();
    }
    @GetMapping("customers/{id}")
        public Optional<CustomerDetails> getCustomerById(@PathVariable long id){
            return customerService.getCustomerById(id);
        }


    @PostMapping("customers")
    public CustomerResponse addCustomer(@RequestBody CustomerDetailedaddress cdo){

        return customerService.addCustomer(cdo);
    }

    @GetMapping("/balance/accountid/{accountId}")
    public AccountBalance getBalanceByAccountId(@PathVariable("accountId") long accountId) {
        return customerService.getBalanceByAccountId(accountId);
    }
    @GetMapping("/balance/customerid/{customerId}")
    public CustomerAccountMap getBalanceByCustomerId(@PathVariable("customerId") long customerId) {
        return customerService.findByCustomerId(customerId);
    }

    @PostMapping("transactions")
    public String createTransaction(@RequestBody TransactionType transactionType){
        String type=transactionType.getType();
        if(type.equals("credit"))
        {
            System.out.println("calling function");
            return customerService.createTransactionCredit(transactionType);
        }
        else
            return "error";
    }
    @GetMapping("transactions")
    public List<AccountTranscation> getTransactionByAccidAndRefid(@RequestParam long accountid, @RequestParam long transactionrefid) {
        return customerService.getTransactionByAccidAndRefid(accountid,transactionrefid);
    }
    @GetMapping("/accountid")
    public List<AccountTranscation> getTransactionByAccid(@RequestParam long accountid){
        return customerService.getTransactionByAccId(accountid);
    }
    @GetMapping("/transactionrefid")
    public List<AccountTranscation> getTransactionByRefid(@RequestParam long transactionrefid){
        return customerService.getTransactionByRefId(transactionrefid);
    }

   @GetMapping("getaddress")
    public List<CustomerAddress> getCustomerAddress(){
        return customerService.getCustomerAddress();
   }

    @PutMapping("/{customerid}")
    public ResponseEntity<CustomerDetailedaddress> updateCustomer(@PathVariable Long customerid, @RequestBody CustomerDetailedaddress customerDetailedaddress) {
        CustomerDetailedaddress updatedCustomer = customerService.updateCustomer(customerid, customerDetailedaddress);
        return new ResponseEntity<>(updatedCustomer, HttpStatus.OK);
    }


}

