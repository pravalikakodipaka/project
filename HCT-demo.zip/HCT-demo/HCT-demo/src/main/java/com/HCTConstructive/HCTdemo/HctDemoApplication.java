package com.HCTConstructive.HCTdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HctDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(HctDemoApplication.class, args);
	}

}
