package com.HCTConstructive.HCTdemo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

import java.sql.Timestamp;
@Entity
@Data
@Table(name="accounttransaction")
public class AccountTranscation {
    @Id
    private long transcationid;
    private long transcationrefid;
    private long accountid;
    private double credit;
    private double debit;
    private double avlbalance;
    private Timestamp lastupdated;



}
