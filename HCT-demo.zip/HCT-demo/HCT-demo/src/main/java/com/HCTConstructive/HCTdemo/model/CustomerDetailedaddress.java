package com.HCTConstructive.HCTdemo.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CustomerDetailedaddress {
    private String name;
    private long phone;
    private String email;
    private String country;
    private String city;
    private String addresslane;
    private long pin;




    public CustomerDetailedaddress(String name, long phone, String email, String country, String city, String addressLane, long pin) {
        this.name = name;
        this.phone = phone;
        this.email = email;
        this.country = country;
        this.city = city;
        this.addresslane = addresslane;
        this.pin = pin;
    }

    public CustomerDetailedaddress() {
    }
}
