package com.HCTConstructive.HCTdemo.repository;

import com.HCTConstructive.HCTdemo.model.AccountBalance;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface AccountBalanceRepostory extends JpaRepository<AccountBalance,Long> {
    @Query(value = "update accbalance set balance=:bal where acc_id=:id ",nativeQuery = true)
    @Modifying
    void updateByAccId(long id,double bal);
}
