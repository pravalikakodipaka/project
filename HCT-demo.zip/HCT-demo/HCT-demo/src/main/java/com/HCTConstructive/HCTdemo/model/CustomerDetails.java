package com.HCTConstructive.HCTdemo.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.sql.Timestamp;
@Entity
@Data
@Getter
@Setter
@Table(name="custdetails")
public class CustomerDetails {
    @Id
    private long customerid;
    @Column(name="custname")
    private String custname;
    @Column
    private String Email;
    @Transient
    private long addressid;
    @Column
    private long phone;
    @Column
    private Timestamp created;
    @Column
    private Timestamp lastUpdated;
   @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name="addressid")
   private  CustomerAddress customerAddress;

}
