package com.HCTConstructive.HCTdemo.model;

public class TransactionType {
    private long accid;
    private long toaccid;
    private String type;
    private double amount;

    public long getAccid() {
        return accid;
    }

    public void setAccid(long accid) {
        this.accid = accid;
    }



    public long getToaccid() {
        return toaccid;
    }

    public void setToaccid(long toaccid) {
        this.toaccid = toaccid;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
