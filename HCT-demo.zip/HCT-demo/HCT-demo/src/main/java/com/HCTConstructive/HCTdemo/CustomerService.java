package com.HCTConstructive.HCTdemo;

import com.HCTConstructive.HCTdemo.controller.ValueRandom;
import com.HCTConstructive.HCTdemo.model.*;
import com.HCTConstructive.HCTdemo.model.Response.CustomerResponse;
import com.HCTConstructive.HCTdemo.model.CustomerDetailedaddress;
import com.HCTConstructive.HCTdemo.model.TransactionType;
import com.HCTConstructive.HCTdemo.repository.*;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.util.*;

@Service
public class CustomerService {

   @Autowired
    CustomerRepository customerRepository;
   @Autowired
    CustomerAddressRepository customerAddressRepository;
   @Autowired
   CustomerAccountMapRepository customerAccountMapRepository;
   @Autowired
   Accounttransactionrepostory accounttransactionrepostory;
    @Autowired
    AccountBalanceRepostory accountBalanceRepostory;




    public List<CustomerDetails> getCustomers() {
        return customerRepository.findAll();
    }

    public double getBalanceByCustId(long customerid) {
        CustomerAccountMap cap=customerAccountMapRepository.findByCustId(customerid);
        long accountid=cap.getAccountid();
        Optional<AccountBalance> ab=accountBalanceRepostory.findById(accountid);
        return ab.get().getAccountbalance();
    }

    public AccountBalance getBalanceByAccountId(long accountId) {
        Optional<AccountBalance> accountBalanceOptional = accountBalanceRepostory.findById(accountId);
        return accountBalanceOptional.orElseThrow(() -> new NotFoundException("Account balance not found for account ID: " + accountId));
    }
    public CustomerAccountMap findByCustomerId(long customerId) {
        return customerAccountMapRepository.findByCustId(customerId);
    }

    public  Optional<CustomerDetails> getCustomerById(long id) {
        return customerRepository.findById((int) id);
    }


   public CustomerResponse addCustomer(CustomerDetailedaddress customerDetailedaddress){
       ValueRandom valueRandom=new ValueRandom();
       CustomerDetails customerDetails=new CustomerDetails();
       long cid=valueRandom.getRandom();
       customerDetails.setCustomerid(cid);
       customerDetails.setCustname(customerDetailedaddress.getName());
       customerDetails.setPhone(customerDetailedaddress.getPhone());
       customerDetails.setEmail(customerDetailedaddress.getEmail());
       Timestamp timestamp=new Timestamp(new Date().getTime());
       customerDetails.setCreated(timestamp);
       customerDetails.setCreated(timestamp);
       CustomerAddress customerAddress=new CustomerAddress();
       long aid=valueRandom.getRandom();
       customerAddress.setAddresslane(customerDetailedaddress.getAddresslane());
       customerAddress.setCity(customerDetailedaddress.getCity());
       customerAddress.setAddressid(aid);
       customerAddress.setPin(customerDetailedaddress.getPin());
       customerAddress.setCountry(customerDetailedaddress.getCountry());
       customerAddress.setLastupdate(timestamp);
       customerDetails.setAddressid(aid);
       customerRepository.save(customerDetails);
       customerAddressRepository.save(customerAddress);
       CustomerAccountMap customeraccountmap=new CustomerAccountMap();
       customeraccountmap.setCustomerid(cid);
       AccountBalance accountBalance=new AccountBalance();
       long accountid=valueRandom.getRandom();
       accountBalance.setAccountid(accountid);
       accountBalance.setAccountbalance(1000.00);
       accountBalanceRepostory.save(accountBalance);
       CustomerAccountMap customerAccountMap=new CustomerAccountMap();
       customerAccountMap.setAccountid(accountid);
       customerAccountMap.setCustomerid(cid);
       customerAccountMapRepository.save(customerAccountMap);
       CustomerResponse cr=new CustomerResponse(customerDetails.getCustname(),customerDetails.getCustomerid(),accountBalance.getAccountid(),accountBalance.getAccountbalance());
       return cr;
   }




    public List<AccountTranscation> getTransactionByAccId(long accountid) {
        return accounttransactionrepostory.findByAccId(accountid);
    }

    public List<AccountTranscation> getTransactionByRefId(long transactionrefid){
       return accounttransactionrepostory.findByRefId(transactionrefid);
    }


    public String createTransactionCredit(TransactionType transactionType) {
        ValueRandom valueRandom=new ValueRandom();
        Timestamp timestamp=new Timestamp(new Date().getTime());
        long accid=transactionType.getAccid();
        long toaccid= transactionType.getToaccid();
        String type=transactionType.getType();
        double amount= transactionType.getAmount();
        long t1= valueRandom.getRandom();
        long t2= valueRandom.getRandom();
        long t3= valueRandom.getRandom();
        AccountTranscation a1=new AccountTranscation();
        AccountTranscation a2=new AccountTranscation();
        a1.setTranscationid(t1);
        a1.setTranscationrefid(t3);
        a1.setAccountid(accid);
        a1.setCredit(0);
        a1.setDebit(amount);
        a1.setLastupdated(timestamp);

        a2.setTranscationid(t2);
        a2.setTranscationrefid(t3);
        a2.setAccountid(accid);
        a2.setCredit(amount);
        a2.setDebit(0);
        a2.setLastupdated(timestamp);
        Optional<AccountBalance> senderOptional = accountBalanceRepostory.findById(accid);
        if (senderOptional.isPresent()) {
            AccountBalance sender = senderOptional.get();
            double senderBalance = sender.getAccountbalance();
            if (senderBalance >= amount) {
                sender.setAccountbalance(senderBalance - amount);
                a1.setAvlbalance(sender.getAccountbalance());
                accounttransactionrepostory.save(a1);
            } else {
                return "Insufficient balance in sender's account";
            }
        } else {
            return "Sender account not found";
        }
        Optional<AccountBalance> receiverOptional = accountBalanceRepostory.findById(toaccid);
        if (receiverOptional.isPresent()) {
            AccountBalance receiver = receiverOptional.get();
            double receiverBalance = receiver.getAccountbalance();
            receiver.setAccountbalance(receiverBalance + amount);
            a2.setAvlbalance(receiver.getAccountbalance());
            accounttransactionrepostory.save(a2);
        } else {
            return "Receiver account not found";
        }

       accounttransactionrepostory.save(a1);
       accounttransactionrepostory.save(a2);

        return "Success";
    }
    @Transactional

    public CustomerDetailedaddress updateCustomer(Long customerid, CustomerDetailedaddress customerDetailedaddress) {
        // Retrieve the customer details from the database
      CustomerDetails customerDetails = customerRepository.findById(Math.toIntExact(customerid))
                .orElseThrow(() -> new RuntimeException("Customer not found"));

        // Update customer details with the new data from the request
        customerDetails.setCustname(customerDetailedaddress.getName());
        customerDetails.setPhone(customerDetailedaddress.getPhone());
        customerDetails.setEmail(customerDetailedaddress.getEmail());

        // Retrieve the associated address details from the customer
        CustomerAddress custAddress = customerDetails.getCustomerAddress();

        // Update address details with the new data from the request
        custAddress.setCountry(customerDetailedaddress.getCountry());
        custAddress.setCity(customerDetailedaddress.getCity());
        custAddress.setAddresslane(customerDetailedaddress.getAddresslane());
        custAddress.setPin(customerDetailedaddress.getPin());

        // Save the updated customer details and address details
        customerRepository.save(customerDetails);
        customerAddressRepository.save(custAddress);
       return customerDetailedaddress;

    }


    public List<CustomerAddress> getCustomerAddress() {
        List<CustomerAddress> customerAddresses=customerAddressRepository.findAll();
        List<CustomerAddress> c=new ArrayList<>();
        for(CustomerAddress i:customerAddresses) {
            CustomerAddress p = new CustomerAddress();
            p.setAddressid(i.getAddressid());
            p.setPin(i.getPin());
            p.getAddresslane(i.getAddresslane(i.getAddresslane()));
            p.setCity(i.getCity());
            p.setCountry(i.getCountry());
            p.setLastupdate(i.getLastupdate());
            c.add(p);
        }
        return c;

    }

    public List<AccountTranscation> getTransactionByAccidAndRefid(long accountid, long transactionrefid) {
        return accounttransactionrepostory.findByAccIdAndRefId(accountid,transactionrefid);
    }



}
