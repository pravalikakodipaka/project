package com.libraryexample.practice.repository;

import com.libraryexample.practice.entity.Book;
import com.libraryexample.practice.entity.Member;
import com.libraryexample.practice.entity.Transaction;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface TransRepo extends JpaRepository<Transaction,String> {

    List<Transaction> findByMember(Member memberId);

    List<Transaction> findByBook(Book bookId);

    List<Transaction> findListByMemberAndBook(Member memberId, Book bookId);

    Optional<Transaction> findByMemberAndBook(Member mmm, Book bbb);
}
