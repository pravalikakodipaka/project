package com.libraryexample.practice.repository;

import com.libraryexample.practice.entity.Book;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface BookRepo extends JpaRepository<Book,String> {
    Book findByTitle(String title);

    

    Book findByIsbn(String isbn);

    Book findByQuantity(int quantity);

    Book findByPublishingYear(int publishingYear);


   // Book findByPublisherName(String publisherName);
    Book findByGenreGenreName(String genreName);

    Book findByPublisherPublisherName(String publisherName);

//    Book findByBookAuthorAuthorAuthorName(String authorName);


    // Book findByAuthorAuthorName(String authorName);


}
