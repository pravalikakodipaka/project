package com.libraryexample.practice.service;

import com.libraryexample.practice.entity.*;
import com.libraryexample.practice.repository.BookRepo;
import com.libraryexample.practice.repository.MemRepo;
import com.libraryexample.practice.repository.TransRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service
public class TransationService {
    @Autowired
    BookRepo bookRepo;
    @Autowired
    MemRepo memRepo;
    @Autowired
    TransRepo transRepo;
    public String borrow(TransactionDetails transactionDetails){
        String bookId = transactionDetails.getBookId();
        String  memberId = transactionDetails.getMemberId();
        String type = transactionDetails.getTransactionType();

        Member mmm = new Member();
        mmm.setMemberId(memberId);

        Book bbb = new Book();
        bbb.setBookId(bookId);

        if(type.equalsIgnoreCase("borrow")) {
            Optional<Transaction> ttt = transRepo.findByMemberAndBook(mmm, bbb);
            if (ttt.isPresent()) {
                return "you have taken the same book already";
            }
            Calendar calendar = Calendar.getInstance();

            calendar.setTime(new Date());

            calendar.add(Calendar.WEEK_OF_YEAR, 2);

            Date dueDate = calendar.getTime();

            Transaction trans = new Transaction();
            Optional<Book> bookPresent = bookRepo.findById(bookId);
            if (bookPresent.isPresent()) {
                Book b = bookPresent.get();
                int quant = b.getQuantity();
                if (quant > 0) {
                    Optional<Member> memPresent = memRepo.findById(memberId);
                    if (memPresent.isPresent()) {
                        Member mem = memPresent.get();
                        b.setQuantity(quant - 1);
                        trans.setTransactionType(type);
                        trans.setDueDate(dueDate);
                        Book bb = bookRepo.save(b);
                        Member mm = memRepo.save(mem);
                        trans.setBook(bb);
                        trans.setMember(mm);
                        transRepo.save(trans);
                    }
                } else {
                    return "BOOK NOT AVAILABLE";
                }
            } else {
                return "BOOK ID NOT PRESENT";
            }
        }
        return "SUCCESSFULL";
    }
    public String returnBook(TransactionDetails transactionDetails){
        String bookId= transactionDetails.getBookId();
        String  memberId= transactionDetails.getMemberId();
        String type = transactionDetails.getTransactionType();




        Member mmm = new Member();
        mmm.setMemberId(memberId);

        Book bbb = new Book();
        bbb.setBookId(bookId);

        Optional<Transaction> ret = transRepo.findByMemberAndBook(mmm,bbb);
        if(ret.isEmpty()){
            return "invalid book return";
        }


        Transaction rt = ret.get();
        Transaction newTrans = new Transaction();
        Book br = rt.getBook();
        int quant = br.getQuantity();
        br.setQuantity(quant+1);
        Book savingBooks = bookRepo.save(br);
        Calendar cal = Calendar.getInstance();
        cal.setTime(rt.getDueDate());
        cal.add(Calendar.WEEK_OF_YEAR,2);
        Date returnDate=cal.getTime();
        newTrans.setTransactionType(type);
        newTrans.setDueDate(rt.getDueDate());
        newTrans.setBook(savingBooks);
        newTrans.setMember(rt.getMember());
        newTrans.setReturnDate(returnDate);
        transRepo.save(newTrans);
        return "BOOK SUCCESSFULLY RETURNED";
    }
    public List<TransactionCreation> getAllTransactions(){
        List<TransactionCreation> l1 = new ArrayList<>();
        List<Transaction> trans = transRepo.findAll();
        for(Transaction tr : trans){
            TransactionCreation tt = new TransactionCreation();
            tt.setTransactionId(tr.getTransactionId());
            tt.setTransactionType(tr.getTransactionType());
            tt.setReturnDate(tr.getReturnDate());
            tt.setDueDate(tr.getDueDate());
            tt.setBookId(tr.getBook().getBookId());
            tt.setMemberId(tr.getMember().getMemberId());
            l1.add(tt);
        }
        return l1;
    }

    public List<TransactionCreation> getTransactionByMemberId(Member memberId){
         final Logger logger = LoggerFactory.getLogger(TransationService.class);
//        List<TransactionCreation> l1 = new ArrayList<>();
//        List<Transaction> trans = transRepo.findByMember(memberId);
//        for(Transaction tr : trans){
//            TransactionCreation tt = new TransactionCreation();
//            tt.setTransactionId(tr.getTransactionId());
//            tt.setTransactionType(tr.getTransactionType());
//            tt.setReturnDate(tr.getReturnDate());
//            tt.setDueDate(tr.getDueDate());
//            tt.setBookId(tr.getBook().getBookId());
//            tt.setMemberId(tr.getMember().getMemberId());
//            l1.add(tt);
//        }
//        return l1;
        try {
            List<Transaction> transactions = transRepo.findByMember(memberId);
            List<TransactionCreation> transactionCreations = new ArrayList<>();

            for (Transaction tr : transactions) {
                TransactionCreation tt = new TransactionCreation();
                tt.setTransactionId(tr.getTransactionId());
                tt.setTransactionType(tr.getTransactionType());
                tt.setReturnDate(tr.getReturnDate());
                tt.setDueDate(tr.getDueDate());
                tt.setBookId(tr.getBook().getBookId());
                tt.setMemberId(tr.getMember().getMemberId());
                transactionCreations.add(tt);
            }

            return transactionCreations;
        } catch (Exception e) {
            logger.error("Error fetching transactions for memberId {}: {}", memberId, e.getMessage());
            // You can handle the exception here, log it, and return an appropriate response or throw it further
            return new ArrayList<>(); // Return an empty list or handle the exception based on your application logic
        }
    }
    public List<TransactionCreation> getTransactionByBookId(Book bookId){
        List<TransactionCreation> l1 = new ArrayList<>();
        List<Transaction> trans = transRepo.findByBook(bookId);
        for(Transaction tr : trans){
            TransactionCreation tt = new TransactionCreation();
            tt.setTransactionId(tr.getTransactionId());
            tt.setTransactionType(tr.getTransactionType());
            tt.setReturnDate(tr.getReturnDate());
            tt.setDueDate(tr.getDueDate());
            tt.setBookId(tr.getBook().getBookId());
            tt.setMemberId(tr.getMember().getMemberId());
            l1.add(tt);
        }
        return l1;
    }
    public List<TransactionCreation> getTransactionByMemberIdAndBookId(Member memberId,Book bookId){
        List<TransactionCreation> l1 = new ArrayList<>();
        List<Transaction> trans = transRepo.findListByMemberAndBook(memberId,bookId);
        for(Transaction tr : trans){
            TransactionCreation tt = new TransactionCreation();
            tt.setTransactionId(tr.getTransactionId());
            tt.setTransactionType(tr.getTransactionType());
            tt.setReturnDate(tr.getReturnDate());
            tt.setDueDate(tr.getDueDate());
            tt.setBookId(tr.getBook().getBookId());
            tt.setMemberId(tr.getMember().getMemberId());
            l1.add(tt);
        }
        return l1;
    }


}
