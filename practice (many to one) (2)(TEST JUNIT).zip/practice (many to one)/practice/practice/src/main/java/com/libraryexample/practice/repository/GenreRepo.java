package com.libraryexample.practice.repository;

import com.libraryexample.practice.entity.Genre;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;
import java.util.UUID;

public interface GenreRepo extends JpaRepository<Genre,String> {
    Optional<Genre> findBygenreName(String genreName);

    Optional<Genre> findByGenreId(String genreId);
}
