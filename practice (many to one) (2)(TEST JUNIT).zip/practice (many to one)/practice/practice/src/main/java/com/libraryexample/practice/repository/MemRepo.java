package com.libraryexample.practice.repository;

import com.libraryexample.practice.entity.Member;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MemRepo extends JpaRepository<Member,String> {
}
