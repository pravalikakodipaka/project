package com.libraryexample.practice.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import lombok.Data;
import org.hibernate.annotations.GenericGenerator;

import java.util.List;
@Entity
@Data
public class Genre {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @GenericGenerator(
            name="UUID",
            strategy = "org.hiberate.id.UUIDGenerator"
    )
    private String  genreId;
    private String genreName;

    @OneToMany(mappedBy = "genre")
    @JsonBackReference
    private List<Book> book;
}
