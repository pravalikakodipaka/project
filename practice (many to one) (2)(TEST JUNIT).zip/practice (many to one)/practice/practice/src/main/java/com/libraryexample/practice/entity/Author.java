package com.libraryexample.practice.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Data;
import org.hibernate.annotations.GenericGenerator;

import java.util.List;
import java.util.UUID;

@Entity
@Data
public class Author {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @GenericGenerator(
            name="UUID",
            strategy = "org.hiberate.id.UUIDGenerator"
    )
    private String authorId;
    private String authorName;

   @OneToMany(mappedBy = "author")
  @JsonIgnore
    private List<BookAuthor> bookAuthor;
}
