package com.libraryexample.practice.service;

import com.libraryexample.practice.entity.*;
import com.libraryexample.practice.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class BookService {
    @Autowired
    AuthorRepo authorRepo;
    @Autowired
    BookRepo bookRepo;
    @Autowired
    MemRepo memRepo;
    @Autowired
    PubRepo pubRepo;
    @Autowired
    GenreRepo genreRepo;
    @Autowired
    BookAuthorRepo bookAuthorRepo;
    public BookDetails.CreationDto create(BookDetails.CreationDto creationDto) {

        Genre g = new Genre();
        Genre gg;
        Optional<Genre> op = genreRepo.findBygenreName(creationDto.getGenre().getGenreName());
        if(op.isEmpty()){
            g.setGenreName(creationDto.getGenre().getGenreName());
            gg = genreRepo.save(g);
        }
        else{
            gg = op.get();
        }


        Publisher p = new Publisher();
        Publisher pp;
        Optional<Publisher> po = pubRepo.findBypublisherName(creationDto.getPublisher().getPublisherName());
        if(po.isEmpty()){

            p.setPublisherName(creationDto.getPublisher().getPublisherName());
            pp = pubRepo.save(p);
        }
        else{
            pp = po.get();
        }

        Author a = new Author();
        Author aa;
        Optional<Author> ao = authorRepo.findByAuthorName(creationDto.getAuthor().getAuthorName());
        if(ao.isEmpty()){

            a.setAuthorName(creationDto.getAuthor().getAuthorName());
            aa = authorRepo.save(a);
        }
        else{
            aa = ao.get();
        }


        Book b = new Book();

        b.setTitle(creationDto.getTitle());
        b.setIsbn(creationDto.getIsbn());
        b.setPublishingYear(creationDto.getPublishingYear());
        b.setQuantity(creationDto.getQuantity());
        b.setGenre(gg);
        b.setPublisher(pp);
        Book bb = bookRepo.save(b);

        BookAuthor ba = new BookAuthor();
        ba.setBook(bb);
        ba.setAuthor(aa);
        bookAuthorRepo.save(ba);


        creationDto.setGenre(gg);
        creationDto.setPublisher(pp);
        creationDto.setAuthor(aa);

        return creationDto;
    }

    public Member createMem(Member member) {
        Member m = new Member();
        m.setName(member.getName());
        m.setEmail(member.getEmail());
        m.setAddress(member.getAddress());
        m.setPhoneNumber(member.getPhoneNumber());
        return memRepo.save(m);
    }

    public Author getAuthor(String bookId) {
        Book getBook = bookRepo.findById(String.valueOf(bookId)).get();
        BookAuthor getAuthor = getBook.getBookAuthor();
        return getAuthor.getAuthor();
    }

    public List<Book> getByGenre(String genreId) {
        Optional<Genre> g=genreRepo.findByGenreId(genreId);
      if(g.isPresent()){
          Genre genre=g.get();
          return genre.getBook();
      }
      else{
          throw new  IllegalArgumentException("not found"+genreId);
      }
    }

    public List<Member> getAllMem() {
        List<Member> l1 = new ArrayList<>();
        List<Member> m = memRepo.findAll();
        for(Member mm :m){
            Member add = new Member();
            add.setMemberId(mm.getMemberId());
            add.setName(mm.getName());
            add.setEmail(mm.getEmail());
            add.setPhoneNumber(mm.getPhoneNumber());
            add.setAddress(mm.getAddress());
            l1.add(add);
        }
        return l1;
    }
    public Member updateMem(Member member) {
        Optional<Member> existingMember = memRepo.findById(member.getMemberId());

        if (existingMember.isPresent()) {
            Member m = existingMember.get();
            // Update the member's information
            m.setName(member.getName());
            m.setEmail(member.getEmail());
            m.setAddress(member.getAddress());
            m.setPhoneNumber(member.getPhoneNumber());
            // Save the updated member
            return memRepo.save(m);
        } else {
            // Handle the case where the member does not exist
            throw new RuntimeException("Member not found with id: " + member.getMemberId());
        }
    }

    public BookDetails.CreationDto findByTitle(String title) {
        Book book = bookRepo.findByTitle(title);
//        if (book == null) {
//            return null;
//        }

        BookDetails.CreationDto dto = new BookDetails.CreationDto();
        dto.setGenre(book.getGenre());
        dto.setPublisher(book.getPublisher());
        dto.setAuthor(book.getAuthor());
        dto.setIsbn(book.getIsbn());
        dto.setPublishingYear(book.getPublishingYear());
        dto.setQuantity(book.getQuantity());
        return dto;
    }
    public BookDetails.CreationDto findByPublishingYear(int publishingYear){
        Book book=bookRepo.findByPublishingYear(publishingYear);
        BookDetails.CreationDto dto=new BookDetails.CreationDto();
        dto.setTitle(book.getTitle());
        dto.setIsbn(book.getIsbn());
        dto.setAuthor(book.getAuthor());
        dto.setPublisher(book.getPublisher());
        dto.setGenre(book.getGenre());
        dto.setAuthor(book.getAuthor());
        dto.setQuantity(book.getQuantity());
        return  dto;
    }
    public BookDetails.CreationDto findByIsbn(String  isbn){
        Book book=bookRepo.findByIsbn(isbn);
        BookDetails.CreationDto dto=new BookDetails.CreationDto();
        dto.setTitle(book.getTitle());
        dto.setPublishingYear(book.getPublishingYear());
        dto.setAuthor(book.getAuthor());
        dto.setPublisher(book.getPublisher());
        dto.setGenre(book.getGenre());
        dto.setAuthor(book.getAuthor());
        dto.setQuantity(book.getQuantity());
        return  dto;
    }
    public BookDetails.CreationDto findByQuantity(int quantity){
        Book book=bookRepo.findByQuantity(quantity);
        BookDetails.CreationDto dto=new BookDetails.CreationDto();
        dto.setTitle(book.getTitle());
        dto.setIsbn(book.getIsbn());
        dto.setAuthor(book.getAuthor());
        dto.setPublisher(book.getPublisher());
        dto.setGenre(book.getGenre());
        dto.setAuthor(book.getAuthor());
        dto.setPublishingYear(book.getPublishingYear());
        return  dto;
    }

    public BookDetails.CreationDto findByPublisherName(String  publisherName){
        Book book=bookRepo.findByPublisherPublisherName(publisherName);
        BookDetails.CreationDto dto=new BookDetails.CreationDto();
        dto.setTitle(book.getTitle());
        dto.setPublishingYear(book.getPublishingYear());
        dto.setAuthor(book.getAuthor());
        dto.setPublisher(book.getPublisher());
        dto.setGenre(book.getGenre());
        dto.setAuthor(book.getAuthor());
        dto.setQuantity(book.getQuantity());
        return  dto;
    }
    public BookDetails.CreationDto findByGenreName(String  genreName){
        Book book=bookRepo.findByGenreGenreName(genreName);
        BookDetails.CreationDto dto=new BookDetails.CreationDto();
        dto.setTitle(book.getTitle());
        dto.setPublishingYear(book.getPublishingYear());
        dto.setAuthor(book.getAuthor());
        dto.setPublisher(book.getPublisher());
        dto.setAuthor(book.getAuthor());
        dto.setQuantity(book.getQuantity());
        return  dto;
    }

    public List<Book> getAllBooks() {
        List<Book> b = bookRepo.findAll();
        List<Book> addBooks = new ArrayList<>();
        for(Book book:b){
            Book bb = new Book();
            bb.setBookId(book.getBookId());
            bb.setTitle(book.getTitle());
            bb.setIsbn(book.getIsbn());
            bb.setPublishingYear(book.getPublishingYear());
            bb.setQuantity(book.getQuantity());
            addBooks.add(bb);
        }
        return addBooks;
    }
//    public BookDetails.CreationDto findByAuthorName(String  authorName){
//        Book book=bookRepo.findByBookAuthorAuthorAuthorName(authorName);
//        BookDetails.CreationDto dto=new BookDetails.CreationDto();
//        dto.setTitle(book.getTitle());
//        dto.setPublicationYear(book.getPublicationYear());
//        dto.setAuthor(book.getAuthor());
//        dto.setPublisher(book.getPublisher());
//        dto.setAuthor(book.getAuthor());
//        dto.setQuantity(book.getQuantity());
//        return  dto;
//    }


}
