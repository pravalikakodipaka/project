package com.libraryexample.practice.Controller;

import com.libraryexample.practice.entity.*;
import com.libraryexample.practice.service.BookService;
import com.libraryexample.practice.service.TransationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/librarymanage")
public class BookController {
    @Autowired
    BookService bookService;
    @Autowired
    TransationService transationService;
    @PostMapping("/create")
    public BookDetails.CreationDto creation(@RequestBody BookDetails.CreationDto creationDto){
        return bookService.create(creationDto);
    }



    @PostMapping("/member")
    public Member createMembers(@RequestBody Member member){
        return bookService.createMem(member);
    }

    @GetMapping("/author")
    public Author getAuthor(@RequestParam String  bookId){
        return bookService.getAuthor(String.valueOf(bookId));
    }
    @GetMapping("/gen/{genId}")
    public List<Book> getByGenre(@PathVariable("genId") String genreId){
        return this.bookService.getByGenre(genreId);
    }
    @GetMapping("/getmem")
    public List<Member> getAllMembers(){
        return bookService.getAllMem();
    }

    @GetMapping("/title")
    public ResponseEntity<BookDetails.CreationDto> getBookDetailsByTitle(@RequestParam("title") String title){
        BookDetails.CreationDto bookDetails=bookService.findByTitle(title);
        return ResponseEntity.ok(bookDetails);
    }
    @GetMapping("/isbn")
    public ResponseEntity<BookDetails.CreationDto> getBookDetailsByIsbn(@RequestParam("isbn") String isbn){
        BookDetails.CreationDto bookDetails=bookService.findByIsbn(isbn);
        return ResponseEntity.ok(bookDetails);
    }
    @GetMapping("/publicationYear")
    public ResponseEntity<BookDetails.CreationDto> getBookDetailsByPublishingnYear(@RequestParam("publishingYear") int publishingYear){
        BookDetails.CreationDto bookDetails=bookService.findByPublishingYear(publishingYear);
        return ResponseEntity.ok(bookDetails);
    }
    @GetMapping("/quantity")
    public ResponseEntity<BookDetails.CreationDto> getBookDetailsByQuantity(@RequestParam("quantity") int quantity){
        BookDetails.CreationDto bookDetails=bookService.findByQuantity(quantity);
        return ResponseEntity.ok(bookDetails);
    }
    @GetMapping("/publisher")
    public ResponseEntity<BookDetails.CreationDto> getBooksByPublisherName(@RequestParam("publisherName") String publisherName) {
        BookDetails.CreationDto books = bookService.findByPublisherName(publisherName);
        return ResponseEntity.ok(books);
    }
    @GetMapping("/genre")
    public ResponseEntity<BookDetails.CreationDto> getBooksByGenreName(@RequestParam("genreName") String genreName) {
        BookDetails.CreationDto books = bookService.findByGenreName(genreName);
        return ResponseEntity.ok(books);
    }
//    @GetMapping("/author")
//    public ResponseEntity<BookDetails.CreationDto> getBooksByAuthorName(@RequestParam("authorName") String authorName) {
//        BookDetails.CreationDto books = bookService.findByAuthorName(authorName);
//        return ResponseEntity.ok(books);
//    }


    @PostMapping("/transactions/borrow")
    public ResponseEntity<String> borrowBook(@RequestBody TransactionDetails transactionDetails) {
        String response = transationService.borrow(transactionDetails);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @PostMapping("/transactions/return")
    public ResponseEntity<String> returnBook(@RequestBody TransactionDetails transactionDetails) {
        String response = transationService.returnBook(transactionDetails);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }
    @GetMapping("/transactions/all")
    public ResponseEntity<List<TransactionCreation>> getAllTransactions() {
        List<TransactionCreation> transactionCreationList = transationService.getAllTransactions();
        return ResponseEntity.status(HttpStatus.OK).body(transactionCreationList);
    }
    @GetMapping("/member/{memberId}")
    public List<TransactionCreation> getTransactionsByMemberId(@PathVariable Member memberId) {
//        List<TransactionCreation> transactions = transationService.getTransactionByMemberId(memberId);
//        return ResponseEntity.status(HttpStatus.OK).body(transactions);
//        if (transactions.isEmpty()) {
//            return ResponseEntity.notFound().build();
//        }
//        return ResponseEntity.ok(transactions);
        return transationService.getTransactionByMemberId(memberId);
    }
    @GetMapping("/transactions/book/{bookId}")
    public List<TransactionCreation> getTransactionsByBookId(@PathVariable Book bookId) {
        return transationService.getTransactionByBookId(bookId);
    }
    @GetMapping("/transactions/member/{memberId}/book/{bookId}")
    public List<TransactionCreation> getTransactionsByMemberIdAndBookId(@PathVariable Member memberId, @PathVariable Book bookId) {
        return transationService.getTransactionByMemberIdAndBookId(memberId, bookId);
    }
    @PutMapping("/{id}")
    public ResponseEntity<Member> updateMem(@PathVariable("id") long memberId, @RequestBody Member updatedMember) {
        try {
            updatedMember.setMemberId(String.valueOf(memberId)); // Ensure the memberId is set
            Member updated = bookService.updateMem(updatedMember);
            return ResponseEntity.ok(updated);
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }
    }
    @GetMapping("/allBooks")
    public List<Book> getAllBok(){
        return bookService.getAllBooks();
    }

}
