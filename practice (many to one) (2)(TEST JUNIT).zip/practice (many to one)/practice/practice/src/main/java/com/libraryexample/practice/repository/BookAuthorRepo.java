package com.libraryexample.practice.repository;

import com.libraryexample.practice.entity.BookAuthor;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BookAuthorRepo extends JpaRepository<BookAuthor,String> {
}
