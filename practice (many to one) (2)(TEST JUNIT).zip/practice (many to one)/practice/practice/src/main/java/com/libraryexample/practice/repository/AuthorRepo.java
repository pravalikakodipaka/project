package com.libraryexample.practice.repository;

import com.libraryexample.practice.entity.Author;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface AuthorRepo extends JpaRepository<Author,String> {
    Optional<Author> findByAuthorName(String authorName);
}
