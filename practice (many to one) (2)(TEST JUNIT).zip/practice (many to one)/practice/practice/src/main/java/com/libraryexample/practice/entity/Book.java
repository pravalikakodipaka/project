package com.libraryexample.practice.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Data;
import org.hibernate.annotations.GenericGenerator;

import java.util.List;

@Entity
@Data
public class Book {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @GenericGenerator(
            name="UUID",
            strategy = "org.hiberate.id.UUIDGenerator"
    )
    private String bookId;
    private String title;
    private String isbn;
    private int publishingYear;
    private int quantity;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "genreId")
    @JsonIgnore

    private Genre genre;


    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "publisherId")
    @JsonIgnore

    private Publisher publisher;


    @OneToOne(mappedBy = "book")
    @JsonIgnore
    private BookAuthor bookAuthor;

    @OneToMany(mappedBy = "book")
    @JsonIgnore

    private List<Transaction> transaction;

//    public Book(String number, String s, Genre genre) {
//    }


    public Author getAuthor() {
        return bookAuthor != null ? bookAuthor.getAuthor() : null;
    }


    public int getPublishingYear() {
        return publishingYear;
    }
}
