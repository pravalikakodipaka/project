package com.libraryexample.practice.repository;

import com.libraryexample.practice.entity.Publisher;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface PubRepo extends JpaRepository<Publisher,String> {
    Optional<Publisher> findBypublisherName(String publisherName);
}
