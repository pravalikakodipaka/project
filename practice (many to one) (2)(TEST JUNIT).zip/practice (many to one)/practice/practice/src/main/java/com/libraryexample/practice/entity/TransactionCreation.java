package com.libraryexample.practice.entity;

import lombok.Data;

import java.util.Date;
@Data
public class TransactionCreation {
    String bookId;
    String memberId;
    private long transactionId;
    private String transactionType;
    private Date dueDate;
    private Date returnDate;

    public void setTransactionId(String transactionIdString) {
    }
}
