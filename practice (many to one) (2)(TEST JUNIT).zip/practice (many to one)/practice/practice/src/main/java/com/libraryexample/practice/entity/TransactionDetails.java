package com.libraryexample.practice.entity;

import lombok.Data;

@Data
public class TransactionDetails {
    private String bookId;
    private String  memberId;
    private String transactionType;
}
