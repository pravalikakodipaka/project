package com.libraryexample.practice.entity;

import lombok.Data;

public class BookDetails {
    @Data
    public static class CreationDto {

       // private String  bookId;
        private Genre genre;
        private Publisher publisher;
        private Author author;
        private String title;
        private String isbn;
        private int publishingYear;
        private int quantity;

    }
}
