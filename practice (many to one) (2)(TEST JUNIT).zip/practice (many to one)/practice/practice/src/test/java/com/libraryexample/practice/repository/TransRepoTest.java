package com.libraryexample.practice.repository;

import com.libraryexample.practice.entity.*;
import com.libraryexample.practice.service.BookService;
import com.libraryexample.practice.service.TransationService;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class TransRepoTest {
  @Mock
  TransRepo transRepo;
  @InjectMocks
    TransationService transationService;
    @BeforeEach
    void setUp() {
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    void findByMember() {
        String memberId="123";
        Member member=new Member();
        member.setMemberId(memberId);
        member.setName("name");
        member.setAddress("address");
        member.setEmail("@gmail.com");
        member.setPhoneNumber(0000);
        Transaction transaction=new Transaction();
        transaction.setTransactionType("borrow");
        transaction.setTransactionId("78");
        transaction.setMember(member);
        Book book=new Book();
        book.setQuantity(12);
        book.setBookId("9999");
        book.setIsbn("12345");
        book.setTitle("title");
        Publisher publisher=new Publisher();
        publisher.setPublisherName("publisher");
        book.setPublisher(publisher);
        Genre genre=new Genre();
        genre.setGenreName("genre");
        transaction.setBook(book);
        List<Transaction> list=new ArrayList<>();
        list.add(transaction);
        when(transRepo.findByMember(member)).thenReturn(list);
        List<TransactionCreation> res=transationService.getTransactionByMemberId(member);
//        assertNotNull(res);
        assertEquals(list.size(),res.size());
    }

    @Test
    void findByBook() {
        String bookId="123";
        Member member=new Member();
        member.setMemberId("5555");
        member.setName("name");
        member.setAddress("address");
        member.setEmail("@gmail.com");
        member.setPhoneNumber(0000);
        Transaction transaction=new Transaction();
        transaction.setTransactionType("borrow");
        transaction.setTransactionId("78");
        transaction.setMember(member);
        Book book=new Book();
        book.setQuantity(12);
        book.setBookId("9999");
        book.setIsbn("12345");
        book.setTitle("title");
        book.setBookId(bookId);
        Publisher publisher=new Publisher();
        publisher.setPublisherName("publisher");
        book.setPublisher(publisher);
        Genre genre=new Genre();
        genre.setGenreName("genre");
        transaction.setBook(book);
        List<Transaction> list=new ArrayList<>();
        list.add(transaction);
        when(transRepo.findByBook(book)).thenReturn(list);
        List<TransactionCreation> res=transationService.getTransactionByBookId(book);
//        assertNotNull(res);
        assertEquals(list.size(),res.size());
    }

    @Test
    void findListByMemberAndBook() {
        String memberId="123";
        String bookId="2222";
        Member member=new Member();
        member.setMemberId(memberId);
        member.setName("name");
        member.setAddress("address");
        member.setEmail("@gmail.com");
        member.setPhoneNumber(0000);
        Transaction transaction=new Transaction();
        transaction.setTransactionType("borrow");
        transaction.setTransactionId("78");
        transaction.setMember(member);
        Book book=new Book();
        book.setQuantity(12);
        book.setBookId("9999");
        book.setIsbn("12345");
        book.setTitle("title");
        book.setBookId(bookId);
        Publisher publisher=new Publisher();
        publisher.setPublisherName("publisher");
        book.setPublisher(publisher);
        Genre genre=new Genre();
        genre.setGenreName("genre");
        transaction.setBook(book);
        List<Transaction> list=new ArrayList<>();
        list.add(transaction);
        when(transRepo.findListByMemberAndBook(member,book)).thenReturn(list);
        List<TransactionCreation> res=transationService.getTransactionByMemberIdAndBookId(member,book);
//        assertNotNull(res);
        assertEquals(list.size(),res.size());
    }

//    @Test
//    void findByMemberAndBook() {
//    }
}