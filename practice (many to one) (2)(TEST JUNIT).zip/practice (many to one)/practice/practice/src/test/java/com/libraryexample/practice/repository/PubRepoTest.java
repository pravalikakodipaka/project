package com.libraryexample.practice.repository;

import com.libraryexample.practice.entity.Book;
import com.libraryexample.practice.entity.BookDetails;
import com.libraryexample.practice.entity.Genre;
import com.libraryexample.practice.entity.Publisher;
import com.libraryexample.practice.service.BookService;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;
@ExtendWith(MockitoExtension.class)
class PubRepoTest {
 @Mock
 PubRepo pubRepo;
 @Mock
 BookRepo bookRepo;
 @InjectMocks
    BookService bookService;
    @BeforeEach
    void setUp() {
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    void findBypublisherName() {
        String testPublisherName = "Publisher XYZ";
        Book mockBook = new Book();
        mockBook.setBookId("11");  // Assuming book ID is of type Long
        mockBook.setTitle("Test Book");
        mockBook.setPublishingYear(2022);
//        mockBook.setAuthor("John Doe");
        Publisher publisher=new Publisher();
        publisher.setPublisherName(testPublisherName);
        mockBook.setPublisher(publisher);
        Genre genre=new Genre();
        genre.setGenreName("fiction");
        mockBook.setGenre(genre);
        mockBook.setQuantity(5);

        // Mock the behavior of bookRepo.findByPublisherPublisherName to return the mock book
        Mockito.when(bookRepo.findByPublisherPublisherName(testPublisherName)).thenReturn(mockBook);

        // Call the findByPublisherName method under test
        BookDetails.CreationDto resultDto = bookService.findByPublisherName(testPublisherName);

        // Verify that the result dto is not null and contains the expected values
        Assertions.assertNotNull(resultDto);
        Assertions.assertEquals(mockBook.getTitle(), resultDto.getTitle());
        Assertions.assertEquals(mockBook.getPublishingYear(), resultDto.getPublishingYear());
//        Assertions.assertEquals(mockBook.getAuthor(), resultDto.getAuthor());
        Assertions.assertEquals(mockBook.getPublisher(), resultDto.getPublisher());
        Assertions.assertEquals(mockBook.getGenre(), resultDto.getGenre());
        Assertions.assertEquals(mockBook.getQuantity(), resultDto.getQuantity());
    }
}