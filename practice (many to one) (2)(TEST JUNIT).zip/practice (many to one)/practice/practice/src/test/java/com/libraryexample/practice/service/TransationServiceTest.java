package com.libraryexample.practice.service;

import com.libraryexample.practice.entity.*;
import com.libraryexample.practice.repository.BookRepo;
import com.libraryexample.practice.repository.MemRepo;
import com.libraryexample.practice.repository.TransRepo;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

class TransationServiceTest {
    @Mock
    private TransRepo transRepo;
    @Mock
    private BookRepo bookRepo;
    @Mock
    private MemRepo memRepo;
    @InjectMocks
    private TransationService transationService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    void borrow() {
    TransactionDetails transactionDetails=new TransactionDetails();
    transactionDetails.setMemberId("2");
    transactionDetails.setTransactionType("borrow");
    transactionDetails.setBookId("444");
    Member member=new Member();
    member.setMemberId("2");
    Book book=new Book();
    book.setBookId("444");
    book.setQuantity(1);
        Mockito.when(bookRepo.findById("444")).thenReturn(Optional.of(book));
        Mockito.when(memRepo.findById("2")).thenReturn(Optional.of(member));
        String result = transationService.borrow(transactionDetails);

        Assertions.assertEquals("SUCCESSFULL", result);

        Mockito.verify(bookRepo).save(book);
        Mockito.verify(memRepo).save(member);
        Mockito.verify(transRepo).save(Mockito.any(Transaction.class));
    }
    @Test
    void borrowIdNotPresent(){
        TransactionDetails transactionDetails=new TransactionDetails();
        transactionDetails.setMemberId("2");
        transactionDetails.setTransactionType("borrow");
        transactionDetails.setBookId("444");
        Mockito.when(bookRepo.findById("444")).thenReturn(Optional.empty());

        String result = transationService.borrow(transactionDetails);

        Assertions.assertEquals("BOOK ID NOT PRESENT", result);

        Mockito.verify(bookRepo, Mockito.never()).save(Mockito.any(Book.class));
        Mockito.verify(memRepo, Mockito.never()).save(Mockito.any(Member.class));
        Mockito.verify(transRepo, Mockito.never()).save(Mockito.any(Transaction.class));
    }
    @Test
    void borrow_BookNotAvailable() {
        TransactionDetails transactionDetails = new TransactionDetails();
        transactionDetails.setMemberId("2");
        transactionDetails.setTransactionType("borrow");
        transactionDetails.setBookId("444");

        Book book = new Book();
        book.setBookId("444");
        book.setQuantity(0);
        Mockito.when(bookRepo.findById("444")).thenReturn(Optional.of(book));
        String result = transationService.borrow(transactionDetails);

        Assertions.assertEquals("BOOK NOT AVAILABLE", result);
        Mockito.verify(bookRepo, Mockito.never()).save(Mockito.any(Book.class));
        Mockito.verify(memRepo, Mockito.never()).save(Mockito.any(Member.class));
        Mockito.verify(transRepo, Mockito.never()).save(Mockito.any(Transaction.class));
    }
    @Test
    void borrow_AlreadyBorrowedBook() {
        TransactionDetails transactionDetails = new TransactionDetails();
        transactionDetails.setMemberId("2");
        transactionDetails.setTransactionType("borrow");
        transactionDetails.setBookId("444");
        Member member = new Member();
        member.setMemberId("2");
        Book book = new Book();
        book.setBookId("444");
        Transaction existingTransaction = new Transaction();
        existingTransaction.setBook(book);
        existingTransaction.setMember(member);
        Mockito.when(transRepo.findByMemberAndBook(Mockito.any(Member.class), Mockito.any(Book.class)))
                .thenReturn(Optional.of(existingTransaction));

        String result = transationService.borrow(transactionDetails);

        Assertions.assertEquals("you have taken the same book already", result);
        Mockito.verify(bookRepo, Mockito.never()).save(Mockito.any(Book.class));
        Mockito.verify(memRepo, Mockito.never()).save(Mockito.any(Member.class));
        Mockito.verify(transRepo, Mockito.never()).save(Mockito.any(Transaction.class));
    }

    @Test
    void returnBook() {
        TransactionDetails transactionDetails = new TransactionDetails();
        transactionDetails.setMemberId("1");
        transactionDetails.setBookId("101");
        transactionDetails.setTransactionType("Return");

        Transaction existingTransaction = new Transaction();
        existingTransaction.setTransactionId("1");
        Member member=new Member();
        member.setMemberId("1");
        existingTransaction.setMember(member);
        Book book=new Book();
        book.setBookId("101");
        existingTransaction.setBook(book);
        existingTransaction.setDueDate(new Date());
        Mockito.when(transRepo.findByMemberAndBook(Mockito.any(Member.class), Mockito.any(Book.class)))
                .thenReturn(Optional.of(existingTransaction));
        Mockito.when(bookRepo.save(Mockito.any(Book.class))).thenAnswer(invocation -> invocation.getArgument(0));

        String result = transationService.returnBook(transactionDetails);


        Assertions.assertEquals("BOOK SUCCESSFULLY RETURNED", result);

        Mockito.verify(bookRepo).save(Mockito.any(Book.class));
    }
    @Test
    void returnBook_InvalidTransaction() {
        TransactionDetails transactionDetails = new TransactionDetails();
        transactionDetails.setMemberId("1");
        transactionDetails.setBookId("101");
        transactionDetails.setTransactionType("Return");


        Mockito.when(transRepo.findByMemberAndBook(Mockito.any(Member.class), Mockito.any(Book.class)))
                .thenReturn(Optional.empty());

        String result = transationService.returnBook(transactionDetails);

        Assertions.assertEquals("invalid book return", result);

        Mockito.verify(bookRepo, Mockito.never()).save(Mockito.any(Book.class));
    }

    @Test
    void getAllTransactions() {
        Transaction transaction = new Transaction();
        transaction.setTransactionId("122");
        transaction.setTransactionType("borrow");
        Member member=new Member("123","sweety","address",123,"@gmail.com");
        transaction.setMember(member);
        Book book=new Book();
        book.setBookId("888");
        book.setTitle("home");
        book.setIsbn("12357");
        book.setPublishingYear(2020);
        book.setQuantity(12);
        transaction.setBook(book);

        List<Transaction> transactionCreationList = new ArrayList<>();
        transactionCreationList.add(transaction);

        Mockito.when(transRepo.findAll()).thenReturn(transactionCreationList);

        List<TransactionCreation> transactionCreations = transationService.getAllTransactions();
        Assertions.assertNotNull(transactionCreations);
        Assertions.assertEquals(transactionCreationList.size(), transactionCreations.size());


    }

    @Test
    void getTransactionByMemberId() {
        String memberId="123";
        Member member=new Member();
        member.setMemberId(memberId);
        member.setName("name");
        member.setAddress("address");
        member.setEmail("@gmail.com");
        member.setPhoneNumber(0000);
        Transaction transaction=new Transaction();
        transaction.setTransactionType("borrow");
        transaction.setTransactionId("78");
        transaction.setMember(member);
        Book book=new Book();
        book.setQuantity(12);
        book.setBookId("9999");
        book.setIsbn("12345");
        book.setTitle("title");
        Publisher publisher=new Publisher();
        publisher.setPublisherName("publisher");
        book.setPublisher(publisher);
        Genre genre=new Genre();
        genre.setGenreName("genre");
        transaction.setBook(book);
        List<Transaction> list=new ArrayList<>();
        list.add(transaction);
        when(transRepo.findByMember(member)).thenReturn(list);
        List<TransactionCreation> res=transationService.getTransactionByMemberId(member);
//        assertNotNull(res);
        assertEquals(list.size(),res.size());
    }
    @Test
    public void testGetTransactionByMemberId_Exception() {

        Member memberId = new Member();
        memberId.setMemberId("1");

        when(transRepo.findByMember(memberId)).thenThrow(new RuntimeException("Database error"));

        List<TransactionCreation> result = transationService.getTransactionByMemberId(memberId);

        assertTrue(result.isEmpty());
    }

    @Test
    void getTransactionByBookId() {
        String bookId="123";
        Member member=new Member();
        member.setMemberId("5555");
        member.setName("name");
        member.setAddress("address");
        member.setEmail("@gmail.com");
        member.setPhoneNumber(0000);
        Transaction transaction=new Transaction();
        transaction.setTransactionType("borrow");
        transaction.setTransactionId("78");
        transaction.setMember(member);
        Book book=new Book();
        book.setQuantity(12);
        book.setBookId("9999");
        book.setIsbn("12345");
        book.setTitle("title");
        book.setBookId(bookId);
        Publisher publisher=new Publisher();
        publisher.setPublisherName("publisher");
        book.setPublisher(publisher);
        Genre genre=new Genre();
        genre.setGenreName("genre");
        transaction.setBook(book);
        List<Transaction> list=new ArrayList<>();
        list.add(transaction);
        when(transRepo.findByBook(book)).thenReturn(list);
        List<TransactionCreation> res=transationService.getTransactionByBookId(book);

        assertEquals(list.size(),res.size());
    }

    @Test
    void getTransactionByMemberIdAndBookId() {
        String memberId="123";
        String bookId="2222";
        Member member=new Member();
        member.setMemberId(memberId);
        member.setName("name");
        member.setAddress("address");
        member.setEmail("@gmail.com");
        member.setPhoneNumber(0000);
        Transaction transaction=new Transaction();
        transaction.setTransactionType("borrow");
        transaction.setTransactionId("78");
        transaction.setMember(member);
        Book book=new Book();
        book.setQuantity(12);
        book.setBookId("9999");
        book.setIsbn("12345");
        book.setTitle("title");
        book.setBookId(bookId);
        Publisher publisher=new Publisher();
        publisher.setPublisherName("publisher");
        book.setPublisher(publisher);
        Genre genre=new Genre();
        genre.setGenreName("genre");
        transaction.setBook(book);
        List<Transaction> list=new ArrayList<>();
        list.add(transaction);
        when(transRepo.findListByMemberAndBook(member,book)).thenReturn(list);
        List<TransactionCreation> res=transationService.getTransactionByMemberIdAndBookId(member,book);
        assertEquals(list.size(),res.size());
    }
}