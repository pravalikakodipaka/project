package com.libraryexample.practice.repository;

import com.libraryexample.practice.entity.*;
import com.libraryexample.practice.service.BookService;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class GenreRepoTest {
  @Mock
  GenreRepo genreRepo;
  @Mock
  PubRepo pubRepo;
  @InjectMocks
    BookService bookService;
    @BeforeEach
    void setUp() {
    }

    @AfterEach
    void tearDown() {
    }

//    @Test
//    void findBygenreName() {
//        BookDetails.CreationDto creationDto=new BookDetails.CreationDto();
//        Author author=new Author();
//        author.setAuthorName("pravalika");
//        creationDto.setAuthor(author);
//        creationDto.setQuantity(12);
//        creationDto.setIsbn("123");
//        creationDto.setTitle("my home");
//        creationDto.setPublishingYear(2020);
//        Genre genre=new Genre();
//        genre.setGenreName("vardhan");
//        creationDto.setGenre(genre);
//        Publisher publisher=new Publisher();
//        publisher.setPublisherName("swetha");
//        creationDto.setPublisher(publisher);
//        when(genreRepo.findBygenreName(Mockito.anyString())).thenReturn(Optional.empty());
//        when(pubRepo.findBypublisherName(Mockito.anyString())).thenReturn(Optional.empty());
//        when(genreRepo.save(Mockito.any(Genre.class))).thenReturn(genre);
//        when(pubRepo.save(Mockito.any(Publisher.class))).thenReturn(publisher);
//        BookDetails.CreationDto res=bookService.create(creationDto);
//        assertNotNull(res);
//        assertEquals(genre,res.getGenre());
//    }

    @Test
    void findByGenreId() {
        MockitoAnnotations.openMocks(this);

        // Create a sample genre and books
        Genre sampleGenre = new Genre();
        sampleGenre.setGenreId("1"); // Assuming ID "1" exists in the system
        Book book1 = new Book();
        book1.setTitle("Book 1");
        Book book2 = new Book();
        book2.setTitle("Book 2");
        sampleGenre.setBook(List.of(book1, book2));

        // Mock the behavior of genreRepo.findByGenreId to return the sample genre
        when(genreRepo.findByGenreId("1")).thenReturn(Optional.of(sampleGenre));

        // Call the getByGenre method
        List<Book> result = bookService.getByGenre("1");

        // Assert that the result is not null and contains the expected books
        assertNotNull(result);
        assertEquals(2, result.size()); // Assuming 2 books are returned
        assertEquals("Book 1", result.get(0).getTitle());
        assertEquals("Book 2", result.get(1).getTitle());
    }
}