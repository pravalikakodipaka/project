package com.libraryexample.practice.repository;

import com.libraryexample.practice.entity.Book;
import com.libraryexample.practice.entity.BookDetails;
import com.libraryexample.practice.entity.Genre;
import com.libraryexample.practice.entity.Publisher;
import com.libraryexample.practice.service.BookService;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class BookRepoTest {
  @Mock
  BookRepo bookRepo;
  @InjectMocks
    BookService bookService;
    @BeforeEach
    void setUp() {
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    void findByTitle() {
        String title = "Test Book";
        Book mockBook = new Book();
        mockBook.setBookId("11");  // Assuming book ID is of type Long
        mockBook.setTitle(title);
        Genre genre=new Genre();
        genre.setGenreName("name");
        mockBook.setGenre(genre);
        Publisher pub=new Publisher();
        pub.setPublisherName("publisher");
        mockBook.setPublisher(pub);
//        mockBook.setA("John Doe");
        mockBook.setIsbn("1234567890");
        mockBook.setPublishingYear(2022);
        mockBook.setQuantity(5);

        // Mock the repository method to return the mockBook
        Mockito.when(bookRepo.findByTitle(title)).thenReturn(mockBook);

        // Call the service method
        BookDetails.CreationDto resultDto = bookService.findByTitle(title);

        // Debugging outpu

        // Assertions
        assertNotNull(resultDto);
        Assertions.assertEquals(mockBook.getGenre(), resultDto.getGenre());
        Assertions.assertEquals(mockBook.getPublisher(), resultDto.getPublisher());
//        Assertions.assertEquals(mockBook.getAuthor(), resultDto.getAuthor());
        Assertions.assertEquals(mockBook.getIsbn(), resultDto.getIsbn());
        Assertions.assertEquals(mockBook.getPublishingYear(), resultDto.getPublishingYear());
        Assertions.assertEquals(mockBook.getQuantity(), resultDto.getQuantity());


    }

    @Test
    void findByIsbn() {
        String isbn= "Test";
        Book mockBook = new Book();
        mockBook.setBookId("11");  // Assuming book ID is of type Long
        mockBook.setTitle("home");
        Genre genre=new Genre();
        genre.setGenreName("name");
        mockBook.setGenre(genre);
        Publisher pub=new Publisher();
        pub.setPublisherName("publisher");
        mockBook.setPublisher(pub);
//        mockBook.setA("John Doe");
        mockBook.setIsbn(isbn);
        mockBook.setPublishingYear(2022);
        mockBook.setQuantity(5);

        // Mock the behavior of bookRepo.findByTitle to return the mock book
        Mockito.when(bookRepo.findByIsbn(isbn)).thenReturn(mockBook);

        // Call the findByTitle method under test
        BookDetails.CreationDto resultDto = bookService.findByIsbn(isbn);

        // Verify that the result dto is not null and contains the expected values
        Assertions.assertNotNull(resultDto);
        Assertions.assertEquals(mockBook.getGenre(), resultDto.getGenre());
        Assertions.assertEquals(mockBook.getPublisher(), resultDto.getPublisher());
//        Assertions.assertEquals(mockBook.getAuthor(), resultDto.getAuthor());
        Assertions.assertEquals(mockBook.getTitle(), resultDto.getTitle());
        Assertions.assertEquals(mockBook.getPublishingYear(), resultDto.getPublishingYear());
        Assertions.assertEquals(mockBook.getQuantity(), resultDto.getQuantity());
    }

    @Test
    void findByQuantity() {
        int testqQuantity = 12;
        Book mockBook = new Book();
        mockBook.setBookId("11");  // Assuming book ID is of type Long
        mockBook.setTitle("home");
        Genre genre=new Genre();
        genre.setGenreName("name");
        mockBook.setGenre(genre);
        Publisher pub=new Publisher();
        pub.setPublisherName("publisher");
        mockBook.setPublisher(pub);
//        mockBook.setA("John Doe");
        mockBook.setIsbn("1234567890");
        mockBook.setPublishingYear(2022);
        mockBook.setQuantity(testqQuantity);

        // Mock the behavior of bookRepo.findByTitle to return the mock book
        Mockito.when(bookRepo.findByQuantity(testqQuantity)).thenReturn(mockBook);

        // Call the findByTitle method under test
        BookDetails.CreationDto resultDto = bookService.findByQuantity(testqQuantity);

        // Verify that the result dto is not null and contains the expected values
        Assertions.assertNotNull(resultDto);
        Assertions.assertEquals(mockBook.getGenre(), resultDto.getGenre());
        Assertions.assertEquals(mockBook.getPublisher(), resultDto.getPublisher());
//        Assertions.assertEquals(mockBook.getAuthor(), resultDto.getAuthor());
        Assertions.assertEquals(mockBook.getIsbn(), resultDto.getIsbn());
        Assertions.assertEquals(mockBook.getPublishingYear(), resultDto.getPublishingYear());
        Assertions.assertEquals(mockBook.getTitle(), resultDto.getTitle());
    }

    @Test
    void findByPublishingYear() {
        int publicationYear = 2020;
        Book mockBook = new Book();
        mockBook.setBookId("11");  // Assuming book ID is of type Long
        mockBook.setTitle("home");
        Genre genre=new Genre();
        genre.setGenreName("name");
        mockBook.setGenre(genre);
        Publisher pub=new Publisher();
        pub.setPublisherName("publisher");
        mockBook.setPublisher(pub);
//        mockBook.setA("John Doe");
        mockBook.setIsbn("1234567890");
        mockBook.setPublishingYear(publicationYear);
        mockBook.setQuantity(5);

        // Mock the behavior of bookRepo.findByTitle to return the mock book
        Mockito.when(bookRepo.findByPublishingYear(publicationYear)).thenReturn(mockBook);

        // Call the findByTitle method under test
        BookDetails.CreationDto resultDto = bookService.findByPublishingYear(publicationYear);

        // Verify that the result dto is not null and contains the expected values
        Assertions.assertNotNull(resultDto);
        Assertions.assertEquals(mockBook.getGenre(), resultDto.getGenre());
        Assertions.assertEquals(mockBook.getPublisher(), resultDto.getPublisher());
//        Assertions.assertEquals(mockBook.getAuthor(), resultDto.getAuthor());
        Assertions.assertEquals(mockBook.getIsbn(), resultDto.getIsbn());
        Assertions.assertEquals(mockBook.getTitle(), resultDto.getTitle());
        Assertions.assertEquals(mockBook.getQuantity(), resultDto.getQuantity());
    }

    @Test
    void findByGenreGenreName() {
        String tesGenreName = "Genre";
        Book mockBook = new Book();
        mockBook.setBookId("11");  // Assuming book ID is of type Long
        mockBook.setTitle("Test Book");
        mockBook.setPublishingYear(2022);
//        mockBook.setAuthor("John Doe");
        Publisher publisher=new Publisher();
        publisher.setPublisherName("pub");
        mockBook.setPublisher(publisher);
        List<Book> bookList=new ArrayList<>();
        bookList.add(mockBook);
        Genre genre=new Genre();
        genre.setBook(bookList);
        genre.setGenreName(tesGenreName);
        genre.setGenreId("123");
        mockBook.setGenre(genre);
        mockBook.setQuantity(5);


        Mockito.when(bookRepo.findByGenreGenreName(tesGenreName)).thenReturn(mockBook);

        BookDetails.CreationDto resultDto = bookService.findByGenreName(tesGenreName);

        Assertions.assertNotNull(resultDto);
        Assertions.assertEquals(mockBook.getTitle(), resultDto.getTitle());
        Assertions.assertEquals(mockBook.getPublishingYear(), resultDto.getPublishingYear());
//        Assertions.assertEquals(mockBook.getAuthor(), resultDto.getAuthor());
        Assertions.assertEquals(mockBook.getPublisher(), resultDto.getPublisher());
        Assertions.assertEquals(mockBook.getQuantity(), resultDto.getQuantity());
    }

    @Test
    void findByPublisherPublisherName() {
        String testPublisherName = "Publisher XYZ";
        Book mockBook = new Book();
        mockBook.setBookId("11");
        mockBook.setTitle("Test Book");
        mockBook.setPublishingYear(2022);
//        mockBook.setAuthor("John Doe");
        Publisher publisher=new Publisher();
        publisher.setPublisherName(testPublisherName);
        mockBook.setPublisher(publisher);
        Genre genre=new Genre();
        genre.setGenreName("fiction");
        mockBook.setGenre(genre);
        mockBook.setQuantity(5);


        Mockito.when(bookRepo.findByPublisherPublisherName(testPublisherName)).thenReturn(mockBook);


        BookDetails.CreationDto resultDto = bookService.findByPublisherName(testPublisherName);

        Assertions.assertNotNull(resultDto);
        Assertions.assertEquals(mockBook.getTitle(), resultDto.getTitle());
        Assertions.assertEquals(mockBook.getPublishingYear(), resultDto.getPublishingYear());

        Assertions.assertEquals(mockBook.getPublisher(), resultDto.getPublisher());
        Assertions.assertEquals(mockBook.getGenre(), resultDto.getGenre());
        Assertions.assertEquals(mockBook.getQuantity(), resultDto.getQuantity());
    }
}