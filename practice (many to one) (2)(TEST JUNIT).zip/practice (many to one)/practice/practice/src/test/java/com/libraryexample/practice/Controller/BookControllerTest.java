package com.libraryexample.practice.Controller;

import aj.org.objectweb.asm.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.libraryexample.practice.entity.*;
import com.libraryexample.practice.service.BookService;
import com.libraryexample.practice.service.TransationService;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.ResultMatcher;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;

import static org.mockito.Mockito.*;
import static org.springframework.http.RequestEntity.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@ExtendWith(MockitoExtension.class)
@SpringBootTest
@AutoConfigureMockMvc
class BookControllerTest {
    @Autowired
    private MockMvc mockMvc;

    @Mock
    private BookService bookService;
    @Mock
    private TransationService transationService;
    @InjectMocks
    private BookController bookController;


    @BeforeEach
    void setUp() {
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    void creation() throws Exception{
        BookDetails.CreationDto creationDto = new BookDetails.CreationDto();
        creationDto.setTitle("Mock Title");
        creationDto.setIsbn("12345");
        creationDto.setQuantity(12);
        creationDto.setPublishingYear(0);
        Publisher publisher=new Publisher();
        publisher.setPublisherName("pub");
        creationDto.setPublisher(publisher);
        Genre genre=new Genre();
        genre.setGenreName("genre");
        creationDto.setGenre(genre);
        Author author=new Author();
        author.setAuthorName("author");
        creationDto.setAuthor(author);


        ObjectMapper objectMapper = new ObjectMapper();
        String requestJson = objectMapper.writeValueAsString(creationDto);

        // Perform POST request
        mockMvc.perform(MockMvcRequestBuilders.post("/librarymanage/create")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(requestJson))
                .andExpect(status().isOk())
                .andExpect((ResultMatcher) jsonPath("$.title").value("Mock Title"))
                .andExpect(jsonPath("$.isbn").value("12345"));

    }

    @Test
    void createMembers() throws Exception {
        Member mockMember = new Member();
        mockMember.setMemberId("1L");
        mockMember.setName("John Doe");
        mockMember.setAddress("address");
        mockMember.setEmail("@gmail.com");
        mockMember.setPhoneNumber(9999);


        ObjectMapper objectMapper = new ObjectMapper();
        String requestJson = objectMapper.writeValueAsString(mockMember);

        // Perform POST request
        mockMvc.perform(MockMvcRequestBuilders.post("/librarymanage/member")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(requestJson))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("John Doe"))
                .andExpect(jsonPath("$.address").value("address"));
    }

    @Test
    void getAuthor() {
        String bookId = "123";
        Author expectedAuthor = new Author();
        expectedAuthor.setAuthorId("3333");
        expectedAuthor.setAuthorName("error");// Sample author data
        when(bookService.getAuthor(bookId)).thenReturn(expectedAuthor);

        Author result = bookController.getAuthor(bookId);

        assertEquals(expectedAuthor.getAuthorId(), result.getAuthorId());
        assertEquals(expectedAuthor.getAuthorName(), result.getAuthorName());
    }

    @Test
    void getByGenre() throws Exception {

        MockitoAnnotations.openMocks(this);

        // Set up MockMvc for the controller
        mockMvc = MockMvcBuilders.standaloneSetup(bookController).build();

        // Mock the behavior of bookService.getByGenre
        Genre genre = new Genre();
        Book book1 = new Book();
        book1.setTitle("Book 1");
        Book book2 = new Book();
        book2.setTitle("Book 2");
        genre.setBook(Arrays.asList(book1, book2));
        when(bookService.getByGenre(anyString())).thenReturn(genre.getBook());

        // Perform GET request to the endpoint
        mockMvc.perform(get("/librarymanage/gen/1")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$[0].title").value("Book 1"))
                .andExpect(jsonPath("$[1].title").value("Book 2"));
    }



    @Test
    void getAllMembers() throws  Exception{
        List<Member> memberList=new ArrayList<>();
        Member member=new Member();
        member.setMemberId("123");
        member.setName("sweety");
        member.setAddress("address");
        member.setEmail("@gmail.com");
        memberList.add(member);
       mockMvc= MockMvcBuilders.standaloneSetup(bookController).build();
       when(bookService.getAllMem()).thenReturn(memberList);
        mockMvc.perform(get("/librarymanage/getmem"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.size()").value(memberList.size()));
    }

    @Test
    void getBookDetailsByTitle() {
        String title = "Sample Book";
        BookDetails.CreationDto expectedBookDetails = new BookDetails.CreationDto();
        when(bookService.findByTitle(title)).thenReturn(expectedBookDetails);

        ResponseEntity<BookDetails.CreationDto> response = bookController.getBookDetailsByTitle(title);

        // Verify the response
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(expectedBookDetails, response.getBody());
    }

    @Test
    void getBookDetailsByIsbn() {
        String isbn="12345";
        BookDetails.CreationDto creationDto=new BookDetails.CreationDto();
        when(bookService.findByIsbn(isbn)).thenReturn(creationDto);
        ResponseEntity<BookDetails.CreationDto> res=bookController.getBookDetailsByIsbn(isbn);
        assertEquals(HttpStatus.OK,res.getStatusCode());
        assertEquals(creationDto,res.getBody());
    }

    @Test
    void getBookDetailsByPublishingYear() {
        int publishingYear=2011;
        BookDetails.CreationDto creationDto=new BookDetails.CreationDto();
        when(bookService.findByPublishingYear(publishingYear)).thenReturn(creationDto);
        ResponseEntity<BookDetails.CreationDto> res=bookController.getBookDetailsByPublishingnYear(publishingYear);
        assertEquals(HttpStatus.OK,res.getStatusCode());
        assertEquals(creationDto,res.getBody());
    }

    @Test
    void getBookDetailsByQuantity() {
        int quantity=19;
        BookDetails.CreationDto creationDto=new BookDetails.CreationDto();
        when(bookService.findByQuantity(quantity)).thenReturn(creationDto);
        ResponseEntity<BookDetails.CreationDto> res=bookController.getBookDetailsByQuantity(quantity);
        assertEquals(HttpStatus.OK,res.getStatusCode());
        assertEquals(creationDto,res.getBody());
    }

    @Test
    void getBooksByPublisherName() {
       String publisherName="name";
        BookDetails.CreationDto creationDto=new BookDetails.CreationDto();
        when(bookService.findByPublisherName(publisherName)).thenReturn(creationDto);
        ResponseEntity<BookDetails.CreationDto> res=bookController.getBooksByPublisherName(publisherName);
        assertEquals(HttpStatus.OK,res.getStatusCode());
        assertEquals(creationDto,res.getBody());
    }

    @Test
    void getBooksByGenreName() {
        String genreName="ravi";
        BookDetails.CreationDto creationDto=new BookDetails.CreationDto();
        when(bookService.findByGenreName(genreName)).thenReturn(creationDto);
        ResponseEntity<BookDetails.CreationDto> res=bookController.getBooksByGenreName(genreName);
        assertEquals(HttpStatus.OK,res.getStatusCode());
        assertEquals(creationDto,res.getBody());
    }

    @Test
    void borrowBook() throws Exception {
        MockitoAnnotations.openMocks(this);


        mockMvc = MockMvcBuilders.standaloneSetup(bookController).build();


        TransactionDetails transactionDetails = new TransactionDetails();
        transactionDetails.setBookId("123");
        transactionDetails.setMemberId("456");
        transactionDetails.setTransactionType("borrow");


        when(transationService.borrow(any(TransactionDetails.class))).thenReturn("SUCCESSFULL");


        mockMvc.perform(MockMvcRequestBuilders.post("/librarymanage/transactions/borrow")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"bookId\":\"123\",\"memberId\":\"456\",\"transactionType\":\"borrow\"}"))
                .andExpect(status().isOk())
                .andExpect(content().contentTypeCompatibleWith(MediaType.TEXT_PLAIN))
                .andExpect(content().string("SUCCESSFULL"));
    }

    @Test
    void returnBook() throws Exception {
        MockitoAnnotations.openMocks(this);


        mockMvc = MockMvcBuilders.standaloneSetup(bookController).build();

        TransactionDetails transactionDetails = new TransactionDetails();
        transactionDetails.setBookId("123");
        transactionDetails.setMemberId("456");
        transactionDetails.setTransactionType("return");
        when(transationService.returnBook(any(TransactionDetails.class))).thenReturn("BOOK SUCCESSFULLY RETURNED");

        mockMvc.perform(MockMvcRequestBuilders.post("/librarymanage/transactions/return")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"bookId\":\"123\",\"memberId\":\"456\",\"transactionType\":\"return\"}"))
                .andExpect(status().isOk())
                .andExpect(content().contentTypeCompatibleWith(MediaType.TEXT_PLAIN))
                .andExpect(content().string("BOOK SUCCESSFULLY RETURNED"));
    }



    @Test
    void getAllTransactions()  throws Exception{
   List<TransactionCreation> transactionList=new ArrayList<>();
   TransactionCreation transactionCreation=new TransactionCreation();
   transactionCreation.setTransactionId("123");
   transactionCreation.setTransactionType("borrow");
   transactionCreation.setBookId("925157c1-cd15-431f-8ee2-c005a030631f");
   transactionCreation.setMemberId("12222");
   transactionCreation.setDueDate(new Date());
   transactionCreation.setReturnDate(new Date());
   transactionList.add(transactionCreation);
  mockMvc.perform(get("/librarymanage/transactions/all"))
          .andDo(print()).andExpect(status().isOk());
    }

    @Test
    void testGetTransactionsByMemberId() throws Exception {
        String memId = "90b5e4e0-0d8d-4804-b271-3e9ca8d74dc7";
        TransactionCreation tt =  new TransactionCreation();
        tt.setTransactionId("1");
        tt.setMemberId(memId);
        tt.setBookId("111");
        List<TransactionCreation> mockTransactions = new ArrayList<>();
        mockTransactions.add(tt);

        ResultActions response = mockMvc.perform(get("/librarymanage/member/{memberId}", memId))
                .andExpect(status().isOk());
    }

    @Test
    void getTransactionsByBookId() throws Exception{
        String bookId = "6729f518-1b48-4682-9273-11eab60600de"; // Example bookId


        TransactionCreation tt = new TransactionCreation();
        tt.setTransactionId("1");
        tt.setMemberId("123"); // Set a member ID for testing
        tt.setBookId(bookId);

        List<TransactionCreation> mockTransactions = new ArrayList<>();
        mockTransactions.add(tt);

        mockMvc.perform(get("/librarymanage/transactions/book/{bookId}", bookId)
                        .contentType(MediaType.APPLICATION_JSON)) // Set content type if needed
                .andExpect(status().isOk());

    }

    @Test
    void getTransactionsByMemberIdAndBookId() throws Exception {
        String bookId = "6729f518-1b48-4682-9273-11eab60600de";
        String memberId="90b5e4e0-0d8d-4804-b271-3e9ca8d74dc7";

        TransactionCreation tt = new TransactionCreation();
        tt.setTransactionId("1");
        tt.setMemberId(memberId);
        tt.setBookId(bookId);

        List<TransactionCreation> mockTransactions = new ArrayList<>();
        mockTransactions.add(tt);


        mockMvc.perform(get("/librarymanage/transactions/member/{memberId}/book/{bookId}", memberId,bookId)
                        .contentType(MediaType.APPLICATION_JSON)) // Set content type if needed
                .andExpect(status().isOk());
    }

    @Test
    void updateMem() throws Exception{
        MockitoAnnotations.openMocks(this);


        mockMvc = MockMvcBuilders.standaloneSetup(bookController).build();


        Member updatedMember = new Member();
        updatedMember.setMemberId("1");
        updatedMember.setName("John Doe");
        updatedMember.setEmail("john.doe@example.com");
        updatedMember.setAddress("123 Main St");
        updatedMember.setPhoneNumber(1234567890);


        when(bookService.updateMem(updatedMember)).thenReturn(updatedMember);


        mockMvc.perform(put("/librarymanage/{id}", updatedMember.getMemberId())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"memberId\":1,\"name\":\"John Doe\",\"email\":\"john.doe@example.com\",\"address\":\"123 Main St\",\"phoneNumber\":\"1234567890\"}"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.memberId").value(updatedMember.getMemberId()))
                .andExpect(jsonPath("$.name").value(updatedMember.getName()))
                .andExpect(jsonPath("$.email").value(updatedMember.getEmail()))
                .andExpect(jsonPath("$.address").value(updatedMember.getAddress()))
                .andExpect(jsonPath("$.phoneNumber").value(updatedMember.getPhoneNumber()));
    }
    @Test
    void updateMem_RuntimeException_CatchBlock() {

        when(bookService.updateMem(any(Member.class)))
                .thenThrow(new RuntimeException("Member not found with id"));


        Member updatedMember = new Member();
        updatedMember.setMemberId("1");


        ResponseEntity<Member> responseEntity = bookController.updateMem(1L, updatedMember);

        assertEquals(HttpStatus.NOT_FOUND, responseEntity.getStatusCode());
        assertNull(responseEntity.getBody());
    }

    @Test
    void getAllBok()  throws Exception{
        List<Book> bookList=new ArrayList<>();
        Book book=new Book();
        book.setBookId("123");
        book.setPublishingYear(1020);
        book.setQuantity(13);
        book.setIsbn("1234");
        book.setTitle("title");
        Publisher publisher=new Publisher();
        publisher.setPublisherName("ammu");
        book.setPublisher(publisher);
        Genre genre=new Genre();
        genre.setGenreName("madhu");
        book.setGenre(genre);
       bookList.add(book);
       when(bookService.getAllBooks()).thenReturn(bookList);
        mockMvc= MockMvcBuilders.standaloneSetup(bookController).build();
        mockMvc.perform(get("/librarymanage/allBooks"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.size()").value(bookList.size()));
    }
}