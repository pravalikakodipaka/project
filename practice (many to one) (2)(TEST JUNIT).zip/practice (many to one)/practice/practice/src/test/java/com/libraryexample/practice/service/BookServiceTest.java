package com.libraryexample.practice.service;

import com.libraryexample.practice.entity.*;
import com.libraryexample.practice.repository.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class BookServiceTest {
    @Mock
    private AuthorRepo authorRepo;
    @Mock
    private BookAuthorRepo bookAuthorRepo;
    @Mock
    private BookRepo bookRepo;
    @Mock
    private GenreRepo genreRepo;
    @Mock
    private MemRepo memRepo;
    @Mock
    private PubRepo pubRepo;
    @Mock
    private TransRepo transRepo;
    @InjectMocks
    private BookService bookService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    void create() {
        BookDetails.CreationDto creationDto=new BookDetails.CreationDto();
        Author author=new Author();
        author.setAuthorName("pravalika");
        creationDto.setAuthor(author);
        creationDto.setQuantity(12);
        creationDto.setIsbn("123");
        creationDto.setTitle("my home");
        creationDto.setPublishingYear(2020);
        Genre genre=new Genre();
        genre.setGenreName("vardhan");
        creationDto.setGenre(genre);
        Publisher publisher=new Publisher();
        publisher.setPublisherName("swetha");
        creationDto.setPublisher(publisher);
        when(genreRepo.findBygenreName(Mockito.anyString())).thenReturn(Optional.empty());
        when(pubRepo.findBypublisherName(Mockito.anyString())).thenReturn(Optional.empty());
        when(genreRepo.save(Mockito.any(Genre.class))).thenReturn(genre);
        when(pubRepo.save(Mockito.any(Publisher.class))).thenReturn(publisher);
        when(bookRepo.save(Mockito.any(Book.class))).thenAnswer(invocation -> {
            Book savedBook = invocation.getArgument(0);
            savedBook.setBookId("122");;
            return savedBook;
        });
        BookDetails.CreationDto res=bookService.create(creationDto);
        assertNotNull(res);
        assertEquals(genre,res.getGenre());
    }
    @Test
    public void testCreate_ExistingEntities() {

        Genre existingGenre = new Genre();
        existingGenre.setGenreId("1");
        existingGenre.setGenreName("Existing Genre");

        Publisher existingPublisher = new Publisher();
        existingPublisher.setPublisherId("1");
        existingPublisher.setPublisherName("Existing Publisher");

        Author existingAuthor = new Author();
        existingAuthor.setAuthorId("1");
        existingAuthor.setAuthorName("Existing Author");

        when(genreRepo.findBygenreName(anyString())).thenReturn(Optional.of(existingGenre));
        when(pubRepo.findBypublisherName(anyString())).thenReturn(Optional.of(existingPublisher));
        when(authorRepo.findByAuthorName(anyString())).thenReturn(Optional.of(existingAuthor));


        BookDetails.CreationDto creationDto = new BookDetails.CreationDto();
        creationDto.setTitle("Sample Title");
        creationDto.setIsbn("1234567890");
        creationDto.setPublishingYear(2022);
        creationDto.setQuantity(10);

        BookDetails.CreationDto genreDto = new BookDetails.CreationDto();
        Genre genre =new Genre();
        genre.setGenreName("Existing Genre");
        genreDto.setGenre(genre);
        creationDto.setGenre(genreDto.getGenre());

        BookDetails.CreationDto publisherDto = new BookDetails.CreationDto();
        Publisher publisher=new Publisher();
        publisher.setPublisherName("Existing Publisher");
        publisherDto.setPublisher(publisher);
        creationDto.setPublisher(publisherDto.getPublisher());

        BookDetails.CreationDto authorDto = new BookDetails.CreationDto();
        Author author=new Author();
        author.setAuthorName("Existing Author");
        authorDto.setAuthor(author);
        creationDto.setAuthor(authorDto.getAuthor());

        BookDetails.CreationDto result = bookService.create(creationDto);

        assertEquals(existingGenre, result.getGenre());
        assertEquals(existingPublisher, result.getPublisher());
        assertEquals(existingAuthor, result.getAuthor());
    }

    @Test
    void createMem() {
        Member member=new Member("111","prabhath","address",99999,"@gmail.com");
        when(memRepo.save(Mockito.any(Member.class))).thenReturn(member);
        Member mem=bookService.createMem(member);
        assertNotNull(mem);
        assertEquals(member.getName(),mem.getName());
        assertEquals(member.getEmail(),mem.getEmail());
        assertEquals(member.getAddress(),mem.getAddress());
    }

    @Test
    void getAuthor() {
        MockitoAnnotations.openMocks(this);

        Book sampleBook = new Book();
        sampleBook.setBookId("1");
        BookAuthor bookAuthor = new BookAuthor();
        Author author = new Author();
        author.setAuthorName("John Doe");
        bookAuthor.setAuthor(author);
        sampleBook.setBookAuthor(bookAuthor);


        when(bookRepo.findById("1")).thenReturn(Optional.of(sampleBook));

        Author result = bookService.getAuthor("1");

        assertEquals("John Doe", result.getAuthorName());
    }


    @Test
    void getByGenre() {
        MockitoAnnotations.openMocks(this);

        Genre sampleGenre = new Genre();
        sampleGenre.setGenreId("1");
        Book book1 = new Book();
        book1.setTitle("Book 1");
        Book book2 = new Book();
        book2.setTitle("Book 2");
        sampleGenre.setBook(List.of(book1, book2));


        when(genreRepo.findByGenreId("1")).thenReturn(Optional.of(sampleGenre));


        List<Book> result = bookService.getByGenre("1");


        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals("Book 1", result.get(0).getTitle());
        assertEquals("Book 2", result.get(1).getTitle());
    }
    @Test
    public void testGetByGenre_GenreNotFound() {

        when(genreRepo.findByGenreId(anyString())).thenReturn(Optional.empty());


        String nonExistingGenreId = "123";
        try {
            bookService.getByGenre(nonExistingGenreId);
            fail("Expected IllegalArgumentException to be thrown");
        } catch (IllegalArgumentException e) {

            assertEquals("not found" + nonExistingGenreId, e.getMessage());
        }


        verify(genreRepo).findByGenreId(nonExistingGenreId);
    }



    @Test
    public void testGetByGenre_EmptyBookList() {

        MockitoAnnotations.openMocks(this);


        Genre emptyGenre = new Genre();
        emptyGenre.setGenreId("2");
        emptyGenre.setBook(Collections.emptyList());


        when(genreRepo.findByGenreId("2")).thenReturn(Optional.of(emptyGenre));


        List<Book> result = bookService.getByGenre("2");


        assertNotNull(result);
        assertTrue(result.isEmpty());
    }


    @Test
    void getAllMem() {
        Member member=new Member("111","name","address",9999,"@gmail.com");
        List<Member> memberList= new ArrayList<>();
        memberList.add(member);
        when(memRepo.findAll()).thenReturn(memberList);
        List<Member> res= bookService.getAllMem();
        assertEquals(memberList,res);
    }

    @Test
    void findByTitle() {
        String testTitle = "Test Book";
        Book mockBook = new Book();
        mockBook.setBookId("11");
        mockBook.setTitle(testTitle);
        Genre genre=new Genre();
        genre.setGenreName("name");
        mockBook.setGenre(genre);
        Publisher pub=new Publisher();
        pub.setPublisherName("publisher");
        mockBook.setPublisher(pub);
//
        mockBook.setIsbn("1234567890");
        mockBook.setPublishingYear(2022);
        mockBook.setQuantity(5);


        Mockito.when(bookRepo.findByTitle(testTitle)).thenReturn(mockBook);


        BookDetails.CreationDto resultDto = bookService.findByTitle(testTitle);


        Assertions.assertNotNull(resultDto);
        Assertions.assertEquals(mockBook.getGenre(), resultDto.getGenre());
        Assertions.assertEquals(mockBook.getPublisher(), resultDto.getPublisher());

        Assertions.assertEquals(mockBook.getIsbn(), resultDto.getIsbn());
        Assertions.assertEquals(mockBook.getPublishingYear(), resultDto.getPublishingYear());
        Assertions.assertEquals(mockBook.getQuantity(), resultDto.getQuantity());
    }

    @Test
    void findByPublicationYear() {
        int publicationYear = 2020;
        Book mockBook = new Book();
        mockBook.setBookId("11");
        mockBook.setTitle("home");
        Genre genre=new Genre();
        genre.setGenreName("name");
        mockBook.setGenre(genre);
        Publisher pub=new Publisher();
        pub.setPublisherName("publisher");
        mockBook.setPublisher(pub);
        mockBook.setIsbn("1234567890");
        mockBook.setPublishingYear(publicationYear);
        mockBook.setQuantity(5);


        Mockito.when(bookRepo.findByPublishingYear(publicationYear)).thenReturn(mockBook);


        BookDetails.CreationDto resultDto = bookService.findByPublishingYear(publicationYear);


        Assertions.assertNotNull(resultDto);
        Assertions.assertEquals(mockBook.getGenre(), resultDto.getGenre());
        Assertions.assertEquals(mockBook.getPublisher(), resultDto.getPublisher());
        Assertions.assertEquals(mockBook.getIsbn(), resultDto.getIsbn());
        Assertions.assertEquals(mockBook.getTitle(), resultDto.getTitle());
        Assertions.assertEquals(mockBook.getQuantity(), resultDto.getQuantity());
    }

    @Test
    void findByIsbn() {
        String isbn= "Test";
        Book mockBook = new Book();
        mockBook.setBookId("11");
        mockBook.setTitle("home");
        Genre genre=new Genre();
        genre.setGenreName("name");
        mockBook.setGenre(genre);
        Publisher pub=new Publisher();
        pub.setPublisherName("publisher");
        mockBook.setPublisher(pub);

        mockBook.setIsbn(isbn);
        mockBook.setPublishingYear(2022);
        mockBook.setQuantity(5);

        Mockito.when(bookRepo.findByIsbn(isbn)).thenReturn(mockBook);


        BookDetails.CreationDto resultDto = bookService.findByIsbn(isbn);
        Assertions.assertNotNull(resultDto);
        Assertions.assertEquals(mockBook.getGenre(), resultDto.getGenre());
        Assertions.assertEquals(mockBook.getPublisher(), resultDto.getPublisher());

        Assertions.assertEquals(mockBook.getTitle(), resultDto.getTitle());
        Assertions.assertEquals(mockBook.getPublishingYear(), resultDto.getPublishingYear());
        Assertions.assertEquals(mockBook.getQuantity(), resultDto.getQuantity());
    }

    @Test
    void findByQuantity() {
        int testqQuantity = 12;
        Book mockBook = new Book();
        mockBook.setBookId("11");
        mockBook.setTitle("home");
        Genre genre=new Genre();
        genre.setGenreName("name");
        mockBook.setGenre(genre);
        Publisher pub=new Publisher();
        pub.setPublisherName("publisher");
        mockBook.setPublisher(pub);
//        mockBook.setA("John Doe");
        mockBook.setIsbn("1234567890");
        mockBook.setPublishingYear(2022);
        mockBook.setQuantity(testqQuantity);

        Mockito.when(bookRepo.findByQuantity(testqQuantity)).thenReturn(mockBook);

        BookDetails.CreationDto resultDto = bookService.findByQuantity(testqQuantity);


        Assertions.assertNotNull(resultDto);
        Assertions.assertEquals(mockBook.getGenre(), resultDto.getGenre());
        Assertions.assertEquals(mockBook.getPublisher(), resultDto.getPublisher());
        Assertions.assertEquals(mockBook.getIsbn(), resultDto.getIsbn());
        Assertions.assertEquals(mockBook.getPublishingYear(), resultDto.getPublishingYear());
        Assertions.assertEquals(mockBook.getTitle(), resultDto.getTitle());
    }

    @Test
    void findByPublisherName() {
        String testPublisherName = "Publisher";
        Book mockBook = new Book();
        mockBook.setBookId("11");
        mockBook.setTitle("Test Book");
        mockBook.setPublishingYear(2022);
        Publisher publisher=new Publisher();
        publisher.setPublisherName(testPublisherName);
        mockBook.setPublisher(publisher);
        Genre genre=new Genre();
        genre.setGenreName("fiction");
        mockBook.setGenre(genre);
        mockBook.setQuantity(5);

        Mockito.when(bookRepo.findByPublisherPublisherName(testPublisherName)).thenReturn(mockBook);

        BookDetails.CreationDto resultDto = bookService.findByPublisherName(testPublisherName);

        Assertions.assertNotNull(resultDto);
        Assertions.assertEquals(mockBook.getTitle(), resultDto.getTitle());
        Assertions.assertEquals(mockBook.getPublishingYear(), resultDto.getPublishingYear());
//        Assertions.assertEquals(mockBook.getAuthor(), resultDto.getAuthor());
        Assertions.assertEquals(mockBook.getPublisher(), resultDto.getPublisher());
        Assertions.assertEquals(mockBook.getGenre(), resultDto.getGenre());
        Assertions.assertEquals(mockBook.getQuantity(), resultDto.getQuantity());
    }

    @Test
    void findByGenreName() {

        MockitoAnnotations.openMocks(this);

        String genreName = "Science Fiction";

        Book sampleBook = new Book();
        sampleBook.setTitle("Sample Book");
        sampleBook.setPublishingYear(2022);
        BookAuthor bookAuthor=new BookAuthor();
        Author author=new Author();
        author.setAuthorName("author");
        bookAuthor.setAuthor(author);
        bookAuthor.setBook(sampleBook);
        sampleBook.setBookAuthor(bookAuthor);
        Publisher publisher=new Publisher();
        publisher.setPublisherName("pub");
        publisher.setPublisherId("11");
        sampleBook.setPublisher(publisher);
        sampleBook.setQuantity(10);
        Genre genre=new Genre();
        genre.setGenreName(genreName);
        genre.setGenreId("122");
        List<Book> book=new ArrayList<>();
        genre.setBook(book);
        sampleBook.setGenre(genre);


        when(bookRepo.findByGenreGenreName(genreName)).thenReturn(sampleBook);


        BookDetails.CreationDto resultDto = bookService.findByGenreName(genreName);

        assertEquals(sampleBook.getTitle(), resultDto.getTitle());
        assertEquals(sampleBook.getPublishingYear(), resultDto.getPublishingYear());
        assertEquals(sampleBook.getAuthor(), resultDto.getAuthor());
        assertEquals(sampleBook.getPublisher(), resultDto.getPublisher());
        assertEquals(sampleBook.getQuantity(), resultDto.getQuantity());
    }
    @Test
    void updateMem(){
        MockitoAnnotations.openMocks(this);
        Member updatedMember = new Member();
        updatedMember.setMemberId("1");
        updatedMember.setName("John Doe");
        updatedMember.setEmail("john.doe@example.com");
        updatedMember.setAddress("123 Main St");
        updatedMember.setPhoneNumber(1234567890);


        when(memRepo.findById(updatedMember.getMemberId())).thenReturn(Optional.of(updatedMember));

        when(memRepo.save(any(Member.class))).thenReturn(updatedMember);


        Member result = bookService.updateMem(updatedMember);

        assertEquals(updatedMember.getName(), result.getName());
        assertEquals(updatedMember.getEmail(), result.getEmail());
        assertEquals(updatedMember.getAddress(), result.getAddress());
    }
    @Test
    void memberNotFoundWithId(){
        MockitoAnnotations.openMocks(this);
        Member updatedMember=new Member();
        updatedMember.setMemberId("nonexistent");

        Mockito.when(memRepo.findById(updatedMember.getMemberId())).thenReturn(Optional.empty());


        Assertions.assertThrows(RuntimeException.class, () -> {
            bookService.updateMem(updatedMember);
        });
    }
    @Test
    void getAllBooks(){
        MockitoAnnotations.openMocks(this);

        List<Book> bookList=new ArrayList<>();
        Book book=new Book();
        book.setTitle("title");
        book.setBookId("123");
        book.setPublishingYear(1020);
        book.setQuantity(13);
        book.setIsbn("1234");

        Publisher publisher=new Publisher();
        publisher.setPublisherName("ammu");
        book.setPublisher(publisher);
        Genre genre=new Genre();
        genre.setGenreName("madhu");
        book.setGenre(genre);
        bookList.add(book);


        when(bookRepo.findAll()).thenReturn(bookList);


        List<Book> result = bookService.getAllBooks();


        assertEquals(bookList.size(), result.size());

        assertEquals(bookList.get(0).getTitle(), result.get(0).getTitle());
    }
}