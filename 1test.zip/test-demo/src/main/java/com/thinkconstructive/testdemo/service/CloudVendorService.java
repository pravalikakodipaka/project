package com.thinkconstructive.testdemo.service;

import com.thinkconstructive.testdemo.model.CloudVendor;
import org.springframework.stereotype.Service;

import java.util.List;

public interface CloudVendorService {
    public String createCloudVendor(CloudVendor cloudVendor);
     public String updateCloudVendor(CloudVendor cloudVendor);
     public String updateCloudVendors(List<CloudVendor> cloudVendors);
     public String deleteCloudVendor(String vendorId);
     public CloudVendor getCloudVendor(String vendorId);
     public List<CloudVendor> getAllCloudVendor();
}


