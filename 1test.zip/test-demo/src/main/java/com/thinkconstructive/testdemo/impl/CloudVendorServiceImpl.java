package com.thinkconstructive.testdemo.impl;

import com.thinkconstructive.testdemo.model.CloudVendor;
import com.thinkconstructive.testdemo.repository.CloudVendorRepository;
import com.thinkconstructive.testdemo.service.CloudVendorService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CloudVendorServiceImpl  implements CloudVendorService {
   private final CloudVendorRepository cloudVendorRepository;

    public CloudVendorServiceImpl(CloudVendorRepository cloudVendorRepository) {
        this.cloudVendorRepository = cloudVendorRepository;
    }

    @Override
    public String createCloudVendor(CloudVendor cloudVendor) {
       cloudVendorRepository.save(cloudVendor);
       return "success";
    }
   public String updateCloudVendor(CloudVendor cloudVendor){
        cloudVendorRepository.save(cloudVendor);
        return "successfull";
   }

    public String updateCloudVendors(List<CloudVendor> cloudVendors) {
        StringBuilder result = new StringBuilder();
        for (CloudVendor vendor : cloudVendors) {
            Optional<CloudVendor> existingVendorOptional = cloudVendorRepository.findById(vendor.getVendorId());
            if (existingVendorOptional.isPresent()) {
                CloudVendor existingVendor = existingVendorOptional.get();

                // Update vendorName only if it is not null in the incoming object
                if (vendor.getVendorName() != null) {
                    existingVendor.setVendorName(vendor.getVendorName());
                }
                // Update other fields similarly

                cloudVendorRepository.save(existingVendor);
                result.append("Updated vendor with ID ").append(vendor.getVendorId()).append(".\n");
            } else {
                // Vendor with the specified ID not found in the database
                // You may handle this case accordingly, e.g., log an error
                result.append("Vendor with ID ").append(vendor.getVendorId()).append(" not found.\n");
            }
        }
        return result.toString();
    }


    @Override
    public String deleteCloudVendor(String vendorId) {
        cloudVendorRepository.deleteById(vendorId);
        return "delete success";
    }

    @Override
    public CloudVendor getCloudVendor(String vendorId) {
      return cloudVendorRepository.findById(vendorId).get();
    }

    @Override
    public List<CloudVendor> getAllCloudVendor() {
      return cloudVendorRepository.findAll();
    }
}
