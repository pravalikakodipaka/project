package com.thinkconstructive.testdemo.controller;

import com.thinkconstructive.testdemo.model.CloudVendor;
import com.thinkconstructive.testdemo.service.CloudVendorService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/cloudvendor")
public class CloudVendorController {
    private final CloudVendorService cloudVendorService;

    public CloudVendorController(CloudVendorService cloudVendorService) {
        this.cloudVendorService = cloudVendorService;
    }

    @GetMapping("/{vendorId}")
    public CloudVendor getCloudVendorAPIServices(@PathVariable("vendorId") String vendorId) {
        return cloudVendorService.getCloudVendor(vendorId);
    }

    @GetMapping()
    public List<CloudVendor> getAllCloudVendorAPIServices() {
        return cloudVendorService.getAllCloudVendor();
    }

    @PostMapping
    public String createCloudVendorDetails(@RequestBody CloudVendor cloudvendor) {
        cloudVendorService.createCloudVendor(cloudvendor);
        return "Cloud vendor created successfully";
    }

    @PutMapping("/{updatemultiple}")
    public String  updateCloudVendorDetails(@RequestBody List<CloudVendor> cloudVendors) {
       return cloudVendorService.updateCloudVendors(cloudVendors);

    }

    @DeleteMapping("{vendorId}")
    public String deleteCloudVendorDetails(@PathVariable("vendorId") String vendorId) {
        cloudVendorService.deleteCloudVendor(vendorId);
        return "Deleted successfully";
    }
}

