package com.thinkconstructive.testdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
